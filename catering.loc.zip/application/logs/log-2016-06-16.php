<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-16 09:24:18 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2016-06-16 09:27:04 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2016-06-16 09:36:05 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2016-06-16 09:38:14 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
