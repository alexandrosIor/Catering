<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-28 16:58:22 --> 404 Page Not Found: Faviconico/index
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-28 16:58:22 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:58:23 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-11-28 16:58:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-28 16:58:53 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:58:53 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-11-28 16:59:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-28 16:59:03 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:59:03 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-11-28 16:59:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-28 16:59:06 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:59:06 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-11-28 16:59:07 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-28 16:59:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-28 16:59:08 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:59:08 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-11-28 16:59:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-28 16:59:29 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-11-28 16:59:29 --> 404 Page Not Found: Apple-touch-iconpng/index
