<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-03 18:36:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 18:47:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 18:57:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 19:35:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-03 19:37:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-03 19:38:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-03 19:41:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-03 19:41:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-03 19:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 19:43:37 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-10-03 19:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 19:44:34 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-10-03 19:44:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-03 19:45:09 --> 404 Page Not Found: Faviconico/index
