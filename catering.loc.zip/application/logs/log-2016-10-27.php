<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-27 13:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-27 13:47:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-27 13:47:15 --> 404 Page Not Found: Assets/plugins
