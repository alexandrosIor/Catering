<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-08-10 18:26:48 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 18:27:49 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:27:50 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:27:51 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:28:09 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:28:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 18:28:21 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:29:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-08-10 18:29:28 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:30:45 --> 404 Page Not Found: Admin101/index
ERROR - 2016-08-10 18:30:45 --> 404 Page Not Found: Faviconico/index
