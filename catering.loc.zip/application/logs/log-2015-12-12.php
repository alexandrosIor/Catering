<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-12 11:05:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 11:51:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 11:51:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 11:52:26 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 11:52:26 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 26
ERROR - 2015-12-12 11:52:29 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 11:52:29 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 26
ERROR - 2015-12-12 11:52:48 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 11:52:48 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 26
ERROR - 2015-12-12 11:53:00 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 11:53:00 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 11:53:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 11:53:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 11:55:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:55:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:56:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:58:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:58:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:58:24 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 11:58:24 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 11:59:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 11:59:13 --> Severity: Error --> Call to undefined method Shift_model::get_current_open_shift() C:\projects\catering.loc\application\libraries\Authenticate_lib.php 32
ERROR - 2015-12-12 11:59:50 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 11:59:50 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:00:37 --> Severity: Error --> Call to undefined method Shift_model::get_current_open_shift() C:\projects\catering.loc\application\libraries\Authenticate_lib.php 32
ERROR - 2015-12-12 12:01:00 --> Severity: Notice --> Undefined property: Login::$ci C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 12:01:00 --> Severity: Error --> Call to a member function get_current_open_shift() on null C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:01:25 --> Severity: 4096 --> Object of class Shift_model could not be converted to string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:01:25 --> Severity: Notice --> Object of class Shift_model to string conversion C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:01:25 --> Severity: Notice --> Undefined property: Login::$Object C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:01:25 --> Severity: Error --> Call to a member function get_current_open_shift() on null C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:01:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:01:45 --> Severity: Error --> Call to undefined method Shift_model::get_current_open_shift() C:\projects\catering.loc\application\libraries\Authenticate_lib.php 33
ERROR - 2015-12-12 12:02:19 --> Severity: Warning --> Missing argument 1 for Shift_model::create_new_shift(), called in C:\projects\catering.loc\application\libraries\Authenticate_lib.php on line 39 and defined C:\projects\catering.loc\application\models\Shift_model.php 18
ERROR - 2015-12-12 12:02:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:02:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:03:16 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 12:03:16 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:03:29 --> Severity: Notice --> Undefined property: Authenticate_lib::$shift_model C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:03:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:03:29 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:04:12 --> Severity: Notice --> Undefined property: Login::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 12:04:12 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:04:23 --> Severity: Notice --> Undefined property: Authenticate_lib::$shift_model C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:04:23 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:04:23 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\libraries\Authenticate_lib.php 27
ERROR - 2015-12-12 12:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:04:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:05:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 12:05:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 12:07:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:07:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:08:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:08:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:10:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:10:57 --> Severity: Notice --> Undefined variable: start_date C:\projects\catering.loc\application\models\Shift_model.php 21
ERROR - 2015-12-12 12:10:57 --> Severity: Error --> Call to a member function format() on null C:\projects\catering.loc\application\models\Shift_model.php 21
ERROR - 2015-12-12 12:11:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:11:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:38:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 12:57:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 32
ERROR - 2015-12-12 12:57:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 56
ERROR - 2015-12-12 12:57:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 69
ERROR - 2015-12-12 12:57:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 81
ERROR - 2015-12-12 12:57:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 81
ERROR - 2015-12-12 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 32
ERROR - 2015-12-12 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 56
ERROR - 2015-12-12 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 69
ERROR - 2015-12-12 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 81
ERROR - 2015-12-12 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 81
ERROR - 2015-12-12 13:00:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 15
ERROR - 2015-12-12 13:00:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 19
ERROR - 2015-12-12 13:00:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 23
ERROR - 2015-12-12 13:00:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 15
ERROR - 2015-12-12 13:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 19
ERROR - 2015-12-12 13:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 23
ERROR - 2015-12-12 13:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:00:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:00:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:01:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 15
ERROR - 2015-12-12 13:01:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 19
ERROR - 2015-12-12 13:01:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\main.php 23
ERROR - 2015-12-12 13:01:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:01:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 13:02:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:02:17 --> Severity: Compile Error --> Cannot re-assign $this C:\projects\catering.loc\application\models\Shift_model.php 33
ERROR - 2015-12-12 13:03:12 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:03:12 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:03:49 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:03:49 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:04:33 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:04:33 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:04:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:04:39 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:04:39 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:04:53 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:04:53 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:05:04 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:05:04 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:05:08 --> Severity: Notice --> Undefined property: Shifts::$set_properties C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-12 13:05:08 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:05:48 --> Severity: Notice --> Undefined variable: shift C:\projects\catering.loc\application\controllers\Shifts.php 37
ERROR - 2015-12-12 13:06:05 --> Severity: Notice --> Undefined variable: shift C:\projects\catering.loc\application\controllers\Shifts.php 35
ERROR - 2015-12-12 13:06:05 --> Severity: Error --> Call to a member function get_current_open_shift() on null C:\projects\catering.loc\application\controllers\Shifts.php 35
ERROR - 2015-12-12 13:09:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:09:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:09:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:10:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:10:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:10:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:10:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:11:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:13:40 --> Severity: Error --> Cannot access property started with '\0' C:\projects\catering.loc\application\core\MY_Model.php 27
ERROR - 2015-12-12 13:13:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:13:53 --> Severity: Error --> Cannot access property started with '\0' C:\projects\catering.loc\application\core\MY_Model.php 27
ERROR - 2015-12-12 13:18:23 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:18:38 --> Severity: Error --> Call to undefined method Shifts::shift_model() C:\projects\catering.loc\application\controllers\Shifts.php 33
ERROR - 2015-12-12 13:19:08 --> Severity: Error --> Cannot access property started with '\0' C:\projects\catering.loc\application\core\MY_Model.php 27
ERROR - 2015-12-12 13:30:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:30:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:32:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:33:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:33:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:33:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:33:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:35:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:35:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:35:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:37:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:37:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:37:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:37:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:54:10 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 13:54:12 --> 404 Page Not Found: Tables/ajax_get_tables_for_waiter
ERROR - 2015-12-12 13:54:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:54:47 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 13:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:55:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:55:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:55:17 --> 404 Page Not Found: Tables/ajax_get_tables_for_waiter
ERROR - 2015-12-12 13:57:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:57:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 13:57:45 --> 404 Page Not Found: Store_tables/ajax_get_tables_for_waiter
ERROR - 2015-12-12 14:01:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:01:03 --> Severity: error --> Exception: Unable to locate the model you have specified: Table_model C:\projects\catering.loc\system\core\Loader.php 314
ERROR - 2015-12-12 14:01:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:01:23 --> Severity: Error --> Call to undefined method Store_tables::get_records() C:\projects\catering.loc\application\controllers\Store_tables.php 143
ERROR - 2015-12-12 14:01:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:02:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:06:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:06:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:08:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:09:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:09:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:12:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:14:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:14:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:14:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:16:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:20:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:21:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:22:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:22:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:24:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:25:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:26:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:26:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:28:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:28:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:34:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:34:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:35:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:35:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:35:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:37:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:38:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:39:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:39:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:45:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:45:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:45:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:46:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:48:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:48:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:48:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:50:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:50:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:50:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:52:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:53:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:53:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:54:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:54:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:54:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:57:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:57:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:57:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:58:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:58:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:58:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:59:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 14:59:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:02:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:02:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:03:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:04:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:06:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:06:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:07:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:07:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:08:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:09:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:09:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:09:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:09:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:11:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:11:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:12:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:12:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:14:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:15:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:15:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:16:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:16:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:16:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:17:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:17:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:17:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:17:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 15:33:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 16:54:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 16:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 16:54:55 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 22:37:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 22:37:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:38:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:38:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:38:07 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 22:41:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:46:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:47:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:51:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:57:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 22:58:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:02:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:03:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:06:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:10:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:12:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:39:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-12 23:40:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:40:55 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-12 23:41:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-12 23:41:02 --> 404 Page Not Found: Assets/plugins
