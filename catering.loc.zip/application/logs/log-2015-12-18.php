<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-18 09:05:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-18 09:05:25 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-18 09:05:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 09:05:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 09:06:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 09:07:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:27:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-18 18:27:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:27:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:27:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:27:46 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-18 18:46:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:47:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:47:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:48:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:48:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:49:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:49:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:50:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:50:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:51:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:51:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:52:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:53:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:54:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:55:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:57:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:57:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:57:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:57:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:57:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:58:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 18:58:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:00:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:01:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:03:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:04:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:07:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:07:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:08:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:09:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:09:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:10:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:11:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:18:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:18:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:19:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:20:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:23:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:24:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:26:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:27:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:28:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:29:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:32:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:42:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:42:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:46:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 19:47:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:19:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-18 20:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-18 20:21:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:21:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:22:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:25:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:25:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:26:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:27:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:27:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:31:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:31:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:32:16 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\order_products_view.php 62
ERROR - 2015-12-18 20:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:41:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:42:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:42:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:45:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:47:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:48:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:50:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:51:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:51:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:52:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:52:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:53:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:55:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:56:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:56:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:57:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 20:57:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:14:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:14:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:15:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:15:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:17:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:18:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:19:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:25:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:26:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:26:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:30:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:33:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:33:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:34:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:36:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:36:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:40:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:40:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:41:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:42:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:43:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:51:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:53:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:55:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:56:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 21:58:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:03:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:08:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:11:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:11:12 --> Severity: Parsing Error --> syntax error, unexpected 'col' (T_STRING), expecting ',' or ';' C:\projects\catering.loc\application\views\waiter\order_products_view.php 17
ERROR - 2015-12-18 22:11:25 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\projects\catering.loc\application\views\waiter\order_products_view.php 9
ERROR - 2015-12-18 22:11:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:22:16 --> Severity: Notice --> Undefined property: Orders::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:22:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-18 22:22:41 --> Severity: Notice --> Undefined property: Orders::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:22:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 90
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_products_view.php 30
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_products_view.php 31
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_products_view.php 33
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Undefined property: Orders::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-18 22:23:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_products_view.php 42
ERROR - 2015-12-18 22:23:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:23:57 --> Query error: Unknown column 'store_table_record_id' in 'field list' - Invalid query: INSERT INTO `orders` (`store_table_record_id`, `user_record_id`, `shift_record_id`, `record_id`, `insert_at`, `update_at`, `deleted_at`) VALUES (NULL, '2', NULL, NULL, '2015-12-18 21:23:57', '2015-12-18 21:23:57', NULL)
ERROR - 2015-12-18 22:24:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:25:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-18 22:27:06 --> Query error: Unknown column 'table_record_id' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = NULL, `user_record_id` = '2', `shift_record_id` = NULL, `record_id` = '1', `insert_at` = '2015-12-18 21:25:02', `update_at` = '2015-12-18 21:27:06', `deleted_at` = NULL, `start_date` = NULL, `end_date` = NULL, `table_record_id` = '2'
WHERE `record_id` = '1'
ERROR - 2015-12-18 22:30:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-18 22:32:40 --> 404 Page Not Found: Assets/plugins
