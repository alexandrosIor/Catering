<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-11 20:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-11 20:40:17 --> 404 Page Not Found: Shifts/index
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Undefined property: Shifts::$view_data C:\projects\catering.loc\application\controllers\Shifts.php 10
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Undefined variable: logged_in_member C:\projects\catering.loc\application\views\store_layout_view.php 76
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 76
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Undefined variable: logged_in_member C:\projects\catering.loc\application\views\store_layout_view.php 76
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store_layout_view.php 76
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Undefined variable: menu C:\projects\catering.loc\application\views\store_layout_view.php 80
ERROR - 2015-12-11 20:42:52 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store_layout_view.php 80
ERROR - 2015-12-11 20:42:52 --> Severity: Notice --> Undefined variable: page_title C:\projects\catering.loc\application\views\store_layout_view.php 102
ERROR - 2015-12-11 20:43:21 --> Severity: Notice --> Undefined variable: page_title C:\projects\catering.loc\application\views\store_layout_view.php 102
ERROR - 2015-12-11 20:43:26 --> Severity: Notice --> Undefined variable: page_title C:\projects\catering.loc\application\views\store_layout_view.php 102
ERROR - 2015-12-11 20:44:01 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Shifts.php 11
ERROR - 2015-12-11 21:15:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:16:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:17:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:17:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:22:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:22:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:22:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:23:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:23:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:24:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:24:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:26:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:26:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:27:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:28:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:28:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:29:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:29:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:36:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:40:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:41:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:41:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:42:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:42:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:43:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:43:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:44:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:44:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:44:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:44:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:45:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:45:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:45:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:47:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:47:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:47:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:48:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:48:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:49:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:52:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:54:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:54:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:54:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:55:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:55:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:56:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:56:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:56:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:57:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:57:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:57:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:58:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:58:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:58:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:59:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 21:59:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:00:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:00:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:00:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:01:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:02:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:02:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:03:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:03:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:06:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:06:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:06:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:21:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-11 22:26:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-11 22:27:25 --> 404 Page Not Found: Assets/plugins
