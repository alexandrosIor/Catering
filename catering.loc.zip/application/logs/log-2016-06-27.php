<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-06-27 11:36:27 --> 404 Page Not Found: Fcb/themes
ERROR - 2016-06-27 11:39:01 --> 404 Page Not Found: Fcb/themes
ERROR - 2016-06-27 11:54:51 --> 404 Page Not Found: Fcb/themes
