<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-01 17:17:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-01 17:17:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-01 17:17:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-01 17:17:13 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-01 17:18:15 --> 404 Page Not Found: Assets/plugins
