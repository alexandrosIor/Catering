<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-20 20:10:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-20 20:10:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:10:54 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-20 20:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:15:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:16:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:18:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:27:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:31:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:33:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:34:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:37:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:37:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:39:13 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\order_products_view.php 18
ERROR - 2015-12-20 20:39:13 --> Severity: Notice --> Undefined variable: order_products C:\projects\catering.loc\application\views\waiter\order_products_view.php 25
ERROR - 2015-12-20 20:39:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\order_products_view.php 25
ERROR - 2015-12-20 20:41:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:41:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:41:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:42:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:42:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:44:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:44:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:54:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:54:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:54:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 20:58:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:01:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:02:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:03:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:04:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:06:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:07:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:08:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 21:47:09 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-20 21:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-20 22:13:39 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 13
ERROR - 2015-12-20 22:13:57 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 13
ERROR - 2015-12-20 22:14:15 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 13
ERROR - 2015-12-20 22:15:10 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 17
ERROR - 2015-12-20 22:15:17 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 17
ERROR - 2015-12-20 22:16:00 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 17
ERROR - 2015-12-20 22:16:05 --> Severity: Error --> Call to private method MY_Controller::allow_access() from context 'Users' C:\projects\catering.loc\application\controllers\Users.php 17
ERROR - 2015-12-20 22:18:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:18:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:18:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:19:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:19:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-20 22:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-20 22:20:48 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-20 22:20:48 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-20 22:30:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:30:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:30:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:32:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:33:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:39:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:39:53 --> 404 Page Not Found: Store_tables/ajax_get_tables_for_waiter
ERROR - 2015-12-20 22:40:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:41:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:42:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-20 22:42:12 --> 404 Page Not Found: Assets/plugins
