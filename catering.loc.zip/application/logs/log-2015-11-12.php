<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-12 20:38:43 --> 404 Page Not Found: Faviconico/index
