<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-27 00:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:00:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:01:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:01:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:02:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:04:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:05:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 00:09:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 11:42:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 11:53:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 11:54:33 --> Severity: Notice --> Undefined index: order_record_id C:\projects\catering.loc\application\controllers\Waiter_new_order.php 76
ERROR - 2015-12-27 11:54:33 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\order_products_view.php 18
ERROR - 2015-12-27 11:54:33 --> Severity: Notice --> Undefined variable: order_products C:\projects\catering.loc\application\views\waiter\order_products_view.php 25
ERROR - 2015-12-27 11:54:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\order_products_view.php 25
ERROR - 2015-12-27 11:55:45 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-27 11:55:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 11:55:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 11:56:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 11:56:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:22:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:23:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:23:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:23:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:23:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 12:39:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 12:40:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 13:07:19 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:09:14 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:12:27 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:12:38 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:13:02 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:15:56 --> Severity: Warning --> require(C:\projects\catering.loc\application\libraries/vendor/autoload.php): failed to open stream: No such file or directory C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:15:56 --> Severity: Compile Error --> require(): Failed opening required 'C:\projects\catering.loc\application\libraries/vendor/autoload.php' (include_path='.;C:\xampp\php\PEAR') C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:16:03 --> Severity: Warning --> require(C:\projects\catering.loc\application\libraries/vendor/autoload.php): failed to open stream: No such file or directory C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:16:03 --> Severity: Compile Error --> require(): Failed opening required 'C:\projects\catering.loc\application\libraries/vendor/autoload.php' (include_path='.;C:\xampp\php\PEAR') C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:17:03 --> Severity: Warning --> require(C:\projects\catering.loc\application\libraries\vendor\autoload.php): failed to open stream: No such file or directory C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:17:03 --> Severity: Compile Error --> require(): Failed opening required 'C:\projects\catering.loc\application\libraries\vendor\autoload.php' (include_path='.;C:\xampp\php\PEAR') C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 5
ERROR - 2015-12-27 13:19:05 --> Severity: Error --> Class 'Factory' not found C:\projects\catering.loc\application\controllers\Shell.php 32
ERROR - 2015-12-27 13:19:09 --> Severity: Error --> Class 'Factory' not found C:\projects\catering.loc\application\controllers\Shell.php 32
ERROR - 2015-12-27 13:19:57 --> Severity: Error --> Interface 'MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:20:08 --> Severity: Error --> Interface 'MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:20:52 --> Severity: Error --> Interface 'MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:21:00 --> Severity: Error --> Interface 'MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:21:04 --> Severity: Error --> Interface 'MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:21:47 --> Severity: Compile Error --> Declaration of Websocket_dashboard_application::onOpen() must be compatible with Ratchet\ComponentInterface::onOpen(Ratchet\ConnectionInterface $conn) C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:21:56 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 7
ERROR - 2015-12-27 13:22:04 --> Severity: Error --> Class 'Factory' not found C:\projects\catering.loc\application\controllers\Shell.php 32
ERROR - 2015-12-27 13:22:08 --> Severity: Error --> Class 'Factory' not found C:\projects\catering.loc\application\controllers\Shell.php 32
ERROR - 2015-12-27 13:23:12 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 38
ERROR - 2015-12-27 13:23:12 --> Severity: Error --> Class 'RouteCollection' not found C:\projects\catering.loc\application\controllers\Shell.php 40
ERROR - 2015-12-27 13:25:14 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 38
ERROR - 2015-12-27 13:25:14 --> Severity: Error --> Class 'RouteCollection' not found C:\projects\catering.loc\application\controllers\Shell.php 40
ERROR - 2015-12-27 13:25:59 --> Severity: Error --> Class 'RouteCollection' not found C:\projects\catering.loc\application\controllers\Shell.php 40
ERROR - 2015-12-27 13:26:34 --> Severity: Error --> Class 'RouteCollection' not found C:\projects\catering.loc\application\controllers\Shell.php 40
ERROR - 2015-12-27 13:27:09 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:27:10 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:27:10 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:27:38 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:27:38 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:27:38 --> Severity: Notice --> Undefined property: Shell::$debug C:\projects\catering.loc\application\controllers\Shell.php 51
ERROR - 2015-12-27 13:29:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:31:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:38:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:38:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:46:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:46:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:47:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:47:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:47:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:47:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:47:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:48:18 --> Severity: Error --> Interface 'Ratchet\MessageComponentInterface' not found C:\projects\catering.loc\application\libraries\Websocket_dashboard_application.php 6
ERROR - 2015-12-27 13:48:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:49:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:50:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 13:50:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:03:35 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\projects\catering.loc\system\libraries\Session\Session.php 609
ERROR - 2015-12-27 14:03:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\projects\catering.loc\system\core\Exceptions.php:272) C:\projects\catering.loc\system\helpers\url_helper.php 564
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Missing argument 1 for Websocket_messages_lib::__construct(), called in C:\projects\catering.loc\system\core\Loader.php on line 1247 and defined C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 11
ERROR - 2015-12-27 14:05:37 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:05:37 --> Severity: Notice --> Use of undefined constant NUL - assumed 'NUL' C:\projects\catering.loc\application\controllers\Shell.php 66
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'ip_address' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 277
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'workstation_session_record_id' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 278
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'reminder_text' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 279
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'security_violation' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 280
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'member_info' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 281
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'charge_info' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 282
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'panel_color' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 283
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_1_label' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 284
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_1_value' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 285
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_2_label' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 286
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_2_value' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 287
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_3_label' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 288
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_3_value' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 289
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_total_usage_label' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 290
ERROR - 2015-12-27 14:05:37 --> Severity: Warning --> Illegal string offset 'row_total_usage_value' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 291
ERROR - 2015-12-27 14:05:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:05:37 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:07:16 --> Severity: Warning --> Missing argument 1 for Websocket_messages_lib::__construct(), called in C:\projects\catering.loc\system\core\Loader.php on line 1247 and defined C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 11
ERROR - 2015-12-27 14:07:16 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:07:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:07:16 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:10:11 --> Severity: Warning --> Illegal offset type C:\projects\catering.loc\application\controllers\Shell.php 66
ERROR - 2015-12-27 14:10:11 --> Severity: Notice --> Object of class User_model could not be converted to int C:\projects\catering.loc\application\controllers\Shell.php 66
ERROR - 2015-12-27 14:10:11 --> Unable to load the requested class: E
ERROR - 2015-12-27 14:10:57 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Shell.php 67
ERROR - 2015-12-27 14:11:02 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Shell.php 67
ERROR - 2015-12-27 14:11:23 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Shell.php 67
ERROR - 2015-12-27 14:11:56 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Shell.php 67
ERROR - 2015-12-27 14:11:58 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Shell.php 67
ERROR - 2015-12-27 14:12:18 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:12:18 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:12:18 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:12:54 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:12:54 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:12:54 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:15:32 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:15:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:15:32 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:15:43 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:15:43 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:15:43 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:16:50 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:16:50 --> Severity: Notice --> Undefined property: Websocket_messages_lib::$load C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:16:50 --> Severity: Error --> Call to a member function library() on null C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 23
ERROR - 2015-12-27 14:18:36 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:18:44 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:19:31 --> Severity: Notice --> Undefined variable: user C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 14
ERROR - 2015-12-27 14:19:57 --> Severity: Notice --> Array to string conversion C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 17
ERROR - 2015-12-27 14:21:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:22:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:22:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:23:04 --> Severity: error --> Exception: Could not open socket to "0.0.0.0:8087": The requested address is not valid in its context.
 (10049). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-27 14:23:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:23:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:24:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:25:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:29:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:29:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:30:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:31:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:31:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:31:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:31:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:37:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:41:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:41:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:42:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:43:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:43:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:44:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:45:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:45:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:50:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:51:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:53:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:53:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:53:28 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-27 14:53:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:53:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 14:53:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 14:54:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:55:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:56:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:56:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:57:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:57:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 14:58:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:00:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:02:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:20:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:27:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:28:47 --> Not Found: Shell/test
ERROR - 2015-12-27 15:31:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:31:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:31:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:32:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:32:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:34:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:45:50 --> Severity: Parsing Error --> syntax error, unexpected ''start_date'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 171
ERROR - 2015-12-27 15:45:53 --> Severity: Parsing Error --> syntax error, unexpected ''start_date'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 171
ERROR - 2015-12-27 15:45:54 --> Severity: Parsing Error --> syntax error, unexpected ''start_date'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 171
ERROR - 2015-12-27 15:46:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:46:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:52:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:52:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:52:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:52:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:52:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:53:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:53:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:53:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:53:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:54:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:55:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:55:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:55:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:55:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:56:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:56:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:56:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:56:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:56:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:59:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 15:59:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:00:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 16:06:19 --> Severity: Notice --> Undefined property: Logout::$logged_in_user C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:06:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:06:50 --> Severity: Notice --> Undefined property: Logout::$logged_in_user C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:06:50 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:07:55 --> Severity: Notice --> Undefined property: Logout::$logged_in_user C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:07:55 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:09:11 --> Severity: Notice --> Undefined property: Logout::$logged_in_user C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:09:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:09:43 --> Severity: Notice --> Undefined property: Logout::$logged_in_user C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:09:43 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Logout.php 22
ERROR - 2015-12-27 16:09:43 --> Severity: Error --> Call to a member function get_current_open_shift() on null C:\projects\catering.loc\application\controllers\Logout.php 24
ERROR - 2015-12-27 16:14:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:07 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-27 16:14:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:14:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:15:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:15:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:16:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:16:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:16:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:16:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:21:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:21:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:22:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:22:50 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_record_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-27 16:22:50 --> Severity: Notice --> Undefined index: user_record_id C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 17
ERROR - 2015-12-27 16:22:50 --> Severity: error --> Exception: Connection to 'ws://127.0.0.1/' failed: Server sent invalid upgrade response:
HTTP/1.1 404 Not Found
X-Powered-By: Ratchet/0.3.3

 C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 119
ERROR - 2015-12-27 16:23:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:23:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:23:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 16:23:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 16:23:34 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_record_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-27 16:23:34 --> Severity: Notice --> Undefined index: user_record_id C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 17
ERROR - 2015-12-27 16:23:34 --> Severity: error --> Exception: Connection to 'ws://127.0.0.1/' failed: Server sent invalid upgrade response:
HTTP/1.1 404 Not Found
X-Powered-By: Ratchet/0.3.3

 C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 119
ERROR - 2015-12-27 16:24:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:24:22 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_record_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-27 16:24:22 --> Severity: error --> Exception: Connection to 'ws://127.0.0.1/' failed: Server sent invalid upgrade response:
HTTP/1.1 404 Not Found
X-Powered-By: Ratchet/0.3.3

 C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 119
ERROR - 2015-12-27 16:24:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:24:59 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_record_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-27 16:24:59 --> Severity: error --> Exception: Connection to 'ws://127.0.0.1/' failed: Server sent invalid upgrade response:
HTTP/1.1 404 Not Found
X-Powered-By: Ratchet/0.3.3

 C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 119
ERROR - 2015-12-27 16:25:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:25:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:26:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:26:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:26:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:28:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:29:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:29:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:29:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:40:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:40:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:40:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:48:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:49:06 --> Severity: Parsing Error --> syntax error, unexpected '$post' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Orders.php 116
ERROR - 2015-12-27 16:49:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:52:36 --> Severity: Notice --> Undefined variable: order C:\projects\catering.loc\application\controllers\Orders.php 117
ERROR - 2015-12-27 16:52:36 --> Severity: Error --> Call to a member function store_table_info() on null C:\projects\catering.loc\application\controllers\Orders.php 117
ERROR - 2015-12-27 16:53:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:53:38 --> Severity: Error --> Call to undefined method stdClass::store_table_info() C:\projects\catering.loc\application\controllers\Orders.php 118
ERROR - 2015-12-27 16:55:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:55:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:55:42 --> Severity: Notice --> Undefined variable: datetime_now C:\projects\catering.loc\application\controllers\Orders.php 136
ERROR - 2015-12-27 16:55:42 --> Severity: Warning --> DateTime::diff() expects parameter 1 to be DateTimeInterface, null given C:\projects\catering.loc\application\controllers\Orders.php 136
ERROR - 2015-12-27 16:55:42 --> Severity: Error --> Call to a member function format() on boolean C:\projects\catering.loc\application\controllers\Orders.php 137
ERROR - 2015-12-27 16:56:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:56:39 --> Severity: Notice --> Undefined variable: page_title C:\projects\catering.loc\application\views\store_layout_view.php 109
ERROR - 2015-12-27 16:57:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:58:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:58:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 16:59:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:00:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:01:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:04:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:08:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:08:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:09:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:10:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:11:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:13:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:13:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:14:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:15:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:15:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:16:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:17:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:17:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:18:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:18:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:20:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:20:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:21:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:22:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:22:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:24:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:25:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:26:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:28:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:30:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:33:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:34:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:35:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:35:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:35:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:49:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 17:57:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:00:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:00:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:02:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:02:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:03:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 18:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:49:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 21:50:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:50:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:50:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:54:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 21:57:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:05:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:05:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:52:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-27 22:52:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-27 22:53:55 --> 404 Page Not Found: Assets/plugins
