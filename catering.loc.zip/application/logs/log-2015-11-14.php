<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-14 16:24:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 16:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 16:48:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 16:48:45 --> 404 Page Not Found: Block-buttonshtml/index
ERROR - 2015-11-14 16:48:46 --> 404 Page Not Found: Typographyhtml/index
ERROR - 2015-11-14 16:48:47 --> 404 Page Not Found: Tablesphp/index
ERROR - 2015-11-14 16:49:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 16:49:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:10:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:14:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:14:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:23:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:23:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:23:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:23:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 17:49:08 --> 404 Page Not Found: Ratchetloc/index
ERROR - 2015-11-14 17:49:23 --> 404 Page Not Found: Ratchet/index
ERROR - 2015-11-14 17:49:36 --> 404 Page Not Found: Cateringloc/index
ERROR - 2015-11-14 17:49:44 --> 404 Page Not Found: Cateringloc/index
ERROR - 2015-11-14 17:51:58 --> 404 Page Not Found: Ratchet/index
ERROR - 2015-11-14 17:52:27 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2015-11-14 18:13:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-14 19:03:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:04:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:04:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:05:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:20:39 --> Severity: Notice --> Undefined property: Waiter::$authenticate C:\projects\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-14 19:20:39 --> Severity: Error --> Call to a member function logout() on null C:\projects\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-14 19:22:00 --> Severity: Notice --> Undefined property: Waiter::$authenticate C:\projects\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-14 19:22:00 --> Severity: Error --> Call to a member function logout() on null C:\projects\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-14 19:22:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:22:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:24:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:24:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:24:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:25:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:25:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:44:34 --> Severity: Parsing Error --> syntax error, unexpected 'array' (T_ARRAY), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 272
ERROR - 2015-11-14 19:44:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-14 19:50:11 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\dashboard.php 55
ERROR - 2015-11-14 19:50:29 --> Severity: Notice --> Undefined property: Waiter::$capation C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-14 19:50:29 --> Severity: Notice --> Undefined property: Waiter::$capation C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-14 19:50:29 --> Severity: Notice --> Undefined property: Waiter::$capation C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-14 19:50:29 --> Severity: Notice --> Undefined property: Waiter::$capation C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-14 20:00:36 --> Severity: Notice --> Undefined variable: menu_item C:\projects\catering.loc\application\views\waiter\dashboard.php 53
ERROR - 2015-11-14 20:17:36 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:37 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:37 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:38 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:38 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:17:38 --> 404 Page Not Found: Orders/3
ERROR - 2015-11-14 20:17:39 --> 404 Page Not Found: Orders/4
ERROR - 2015-11-14 20:17:40 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:17:40 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:49 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:17:50 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:17:50 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:17:52 --> 404 Page Not Found: Orders/4
ERROR - 2015-11-14 20:17:52 --> 404 Page Not Found: Orders/3
ERROR - 2015-11-14 20:17:53 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:31 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:32 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:18:32 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 20:18:33 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:33 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:33 --> 404 Page Not Found: Orders/3
ERROR - 2015-11-14 20:18:34 --> 404 Page Not Found: Orders/4
ERROR - 2015-11-14 20:18:34 --> 404 Page Not Found: Orders/4
ERROR - 2015-11-14 20:18:34 --> 404 Page Not Found: Orders/4
ERROR - 2015-11-14 20:18:34 --> 404 Page Not Found: Orders/3
ERROR - 2015-11-14 20:18:35 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:35 --> 404 Page Not Found: Orders/2
ERROR - 2015-11-14 20:18:35 --> 404 Page Not Found: Orders/1
ERROR - 2015-11-14 21:15:56 --> 404 Page Not Found: Tables/index
ERROR - 2015-11-14 21:39:52 --> 404 Page Not Found: Undefined/index
ERROR - 2015-11-14 22:17:19 --> Query error: Invalid default value for 'in_use' - Invalid query: ALTER TABLE `tables`
	ADD `in_use` BIT(1) DEFAULT '0'
ERROR - 2015-11-14 22:26:24 --> 404 Page Not Found: Undefined/index
ERROR - 2015-11-14 22:35:50 --> 404 Page Not Found: Undefined/index
ERROR - 2015-11-14 22:35:52 --> 404 Page Not Found: Undefined/index
