<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-22 00:44:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 00:50:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 00:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 00:52:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 07:48:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 08:05:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:11:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:12:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:13:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:13:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:14:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:15:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:16:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:17:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:18:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:18:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:19:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:22:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:23:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:27:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:27:31 --> Query error: Unknown column 'category' in 'field list' - Invalid query: INSERT INTO `product_categories` (`name`, `description`, `parent`, `record_id`, `insert_at`, `update_at`, `deleted_at`, `category`) VALUES ('test', 'test2', NULL, NULL, '2015-11-22 07:27:31', '2015-11-22 07:27:31', NULL, 'κατηγορία 1')
ERROR - 2015-11-22 08:28:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:29:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:31:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:31:22 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 08:32:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:33:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:34:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:36:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:42:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:47:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:47:55 --> Query error: Unknown column 'parent' in 'field list' - Invalid query: INSERT INTO `product_categories` (`name`, `description`, `parent`, `record_id`, `insert_at`, `update_at`, `deleted_at`, `parent_record_id`) VALUES ('kat1', 'kati1', NULL, NULL, '2015-11-22 07:47:55', '2015-11-22 07:47:55', NULL, '0')
ERROR - 2015-11-22 08:48:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:49:15 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 08:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 08:54:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:29:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:30:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:30:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:30:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:30:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:31:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:31:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:31:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:31:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:32:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:32:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:32:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:32:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_category_model.php 20
ERROR - 2015-11-22 09:34:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:35:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:36:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:37:52 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\controllers\Catalogue.php 117
ERROR - 2015-11-22 09:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:38:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:40:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:41:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:43:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:44:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:44:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:45:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:45:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:47:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:47:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:47:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:48:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:48:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:49:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:51:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:51:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:54:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:54:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:55:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:56:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:56:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:57:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:58:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 09:58:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:02:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:04:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:07:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:07:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:08:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:08:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:10:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:10:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:11:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:13:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:15:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:16:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:16:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:17:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:19:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:20:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:20:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:21:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:24:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:25:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:26:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:26:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:26:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:27:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:29:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:29:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:30:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:37:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:37:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:37:51 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant value - assumed 'value' C:\projects\catering.loc\application\controllers\Catalogue.php 139
ERROR - 2015-11-22 10:38:14 --> Severity: Notice --> Use of undefined constant text - assumed 'text' C:\projects\catering.loc\application\controllers\Catalogue.php 140
ERROR - 2015-11-22 10:39:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:40:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:40:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:41:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:42:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:43:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:44:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:45:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:46:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:46:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:48:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:50:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:50:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:51:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:52:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:53:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:53:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:55:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:55:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:56:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:58:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:59:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 10:59:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:01:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:02:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:02:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:07:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:07:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:08:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:09:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:09:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:11:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:12:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:17:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:18:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:18:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:19:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:20:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:22:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:24:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:25:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:26:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:26:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:26:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:27:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:27:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:28:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:29:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:30:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:34:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:35:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:36:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:36:22 --> Query error: Unknown column 'kat1' in 'field list' - Invalid query: UPDATE `product_categories` SET `name` = 'kat1', `description` = 'kat1', `parent_record_id` = '0', `record_id` = '1', `insert_at` = '2015-11-22 07:48:58', `update_at` = '2015-11-22 10:36:22', `deleted_at` = NULL, `kat1` = 'kat1 kat11'
WHERE `record_id` = '1'
ERROR - 2015-11-22 11:40:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:41:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:41:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:41:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:57:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:59:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 11:59:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:00:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:01:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:01:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:03:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:03:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:03:39 --> 404 Page Not Found: Catalogue/ajax_change_status
ERROR - 2015-11-22 12:03:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:03:56 --> Severity: Error --> Call to undefined method Catalogue::get_record() C:\projects\catering.loc\application\controllers\Catalogue.php 167
ERROR - 2015-11-22 12:04:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:04:22 --> Severity: Error --> Call to undefined method Catalogue::get_record() C:\projects\catering.loc\application\controllers\Catalogue.php 167
ERROR - 2015-11-22 12:04:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:05:01 --> Severity: Notice --> Undefined index: record_id C:\projects\catering.loc\application\controllers\Catalogue.php 167
ERROR - 2015-11-22 12:05:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:06:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:07:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:07:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:07:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:08:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:09:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:11:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:11:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:11:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:11:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:11:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:12:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:12:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:12:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:13:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:14:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:15:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:15:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:15:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:15:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:16:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:17:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:17:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:17:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:18:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:18:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:18:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:18:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:19:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:26:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 12:27:30 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 12:27:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:28:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:28:10 --> Query error: Unknown column 'parent_category_name' in 'field list' - Invalid query: UPDATE `product_categories` SET `name` = 'kat2', `description` = 'kat2', `parent_record_id` = '0', `record_id` = '2', `insert_at` = '2015-11-22 07:49:15', `update_at` = '2015-11-22 11:28:10', `deleted_at` = '2015-11-22 11:19:54', `parent_category_name` = '1'
WHERE `record_id` = '2'
ERROR - 2015-11-22 12:29:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:29:29 --> Severity: Error --> Cannot access empty property C:\projects\catering.loc\application\core\MY_Model.php 27
ERROR - 2015-11-22 12:29:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:30:22 --> Severity: Error --> Cannot access empty property C:\projects\catering.loc\application\core\MY_Model.php 27
ERROR - 2015-11-22 12:30:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:31:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:31:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:31:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:31:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 12:32:51 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 22:22:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-22 22:35:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:36:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:37:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:40:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:41:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:42:07 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 22:42:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:58:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:58:45 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 22:58:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 22:59:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:59:28 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 22:59:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 22:59:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 22:59:54 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 22:59:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 23:00:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:00:19 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 23:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\catalogue\product_modal_form.php 16
ERROR - 2015-11-22 23:00:24 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:01:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:11:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:11:49 --> Severity: Notice --> Undefined property: Catalogue::$product_category_model C:\projects\catering.loc\application\controllers\Catalogue.php 160
ERROR - 2015-11-22 23:11:49 --> Severity: Error --> Call to a member function get_all_records() on null C:\projects\catering.loc\application\controllers\Catalogue.php 160
ERROR - 2015-11-22 23:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:12:19 --> Severity: Notice --> Undefined property: Catalogue::$ci C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:12:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_model.php 19
ERROR - 2015-11-22 23:12:19 --> Severity: Error --> Call to a member function model() on null C:\projects\catering.loc\application\models\Product_model.php 19
ERROR - 2015-11-22 23:13:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:13:22 --> Severity: Notice --> Undefined property: Catalogue::$ci C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:13:22 --> Severity: Notice --> Indirect modification of overloaded property Product_model::$ci has no effect C:\projects\catering.loc\application\models\Product_model.php 19
ERROR - 2015-11-22 23:13:22 --> Severity: Error --> Cannot assign by reference to overloaded object C:\projects\catering.loc\application\models\Product_model.php 19
ERROR - 2015-11-22 23:14:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:14:03 --> Severity: Notice --> Undefined property: Catalogue::$ci C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:14:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Product_model.php 22
ERROR - 2015-11-22 23:14:03 --> Severity: Error --> Call to a member function get_record() on null C:\projects\catering.loc\application\models\Product_model.php 22
ERROR - 2015-11-22 23:14:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:14:29 --> Severity: Error --> Call to a member function un_delete() on null C:\projects\catering.loc\application\controllers\Catalogue.php 232
ERROR - 2015-11-22 23:18:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:18:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:18:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:19:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:19:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:19:36 --> Query error: Unknown column 'category_record_id' in 'field list' - Invalid query: UPDATE `product_categories` SET `name` = 'kat1', `description` = 'kat11', `parent_record_id` = '0', `record_id` = '1', `insert_at` = '2015-11-22 07:48:58', `update_at` = '2015-11-22 22:19:36', `deleted_at` = NULL, `category_record_id` = '7'
WHERE `record_id` = '1'
ERROR - 2015-11-22 23:20:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:20:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:21:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:22:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:22:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:22:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:23:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:23:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:25:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:25:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:25:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:26:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:26:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:26:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:30:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:30:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:31:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:31:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:31:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:31:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:32:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:32:14 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:32:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:38:08 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:38:21 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-22 23:40:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-22 23:40:40 --> 404 Page Not Found: Assets/plugins
