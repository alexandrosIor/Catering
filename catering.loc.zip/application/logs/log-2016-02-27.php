<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-27 17:12:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-02-27 17:29:44 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-02-27 17:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-02-27 17:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-02-27 17:32:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-27 17:32:09 --> 404 Page Not Found: Browserconfigxml/index
