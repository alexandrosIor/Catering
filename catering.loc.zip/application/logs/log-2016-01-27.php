<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-27 19:47:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-27 19:49:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-27 19:49:18 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-27 19:49:59 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-27 19:50:38 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-27 19:51:05 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-27 19:51:09 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-27 19:51:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-27 19:51:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-27 19:51:25 --> 404 Page Not Found: Faviconico/index
