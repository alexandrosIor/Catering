<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-07 20:07:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'catering' C:\xampp\htdocs\catering.loc\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2015-11-07 20:07:05 --> Unable to connect to the database
