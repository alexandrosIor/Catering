<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-07 09:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-07 09:37:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:37:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:38:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:38:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:44:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:45:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:45:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 09:55:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-07 09:55:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-07 10:37:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-07 10:37:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 10:37:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 10:37:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 10:37:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-07 10:40:49 --> 404 Page Not Found: D/store
ERROR - 2016-09-07 10:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-07 10:40:54 --> 404 Page Not Found: D/login
ERROR - 2016-09-07 10:41:09 --> 404 Page Not Found: D/index.php
ERROR - 2016-09-07 10:42:48 --> 404 Page Not Found: D/test.php
ERROR - 2016-09-07 20:48:14 --> 404 Page Not Found: Faviconico/index
