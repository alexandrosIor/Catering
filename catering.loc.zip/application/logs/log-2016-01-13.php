<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-13 00:02:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:05:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:05:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:06:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:07:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:12:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:13:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:14:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:14:26 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:28 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:31 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:14:34 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:38 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:41 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:56 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:14:56 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:03 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:03 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 00:15:09 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:09 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:12 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:12 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:24 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:26 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:29 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:15:42 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-13 00:16:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:54:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:54:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-13 19:55:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:55:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:55:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:55:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 19:58:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:01:08 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-13 20:01:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:01:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:01:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:02:05 --> 404 Page Not Found: Browserconfigxml/index
ERROR - 2016-01-13 20:02:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:03:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-13 20:03:33 --> 404 Page Not Found: Assets/plugins
