<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-22 19:14:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-22 20:08:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-22 20:12:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:17:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:18:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:19:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:24:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:24:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:25:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:27:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:27:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:29:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:30:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 20:34:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:14:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:15:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:17:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:20:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:20:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:21:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:24:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-22 21:27:24 --> 404 Page Not Found: Assets/plugins
