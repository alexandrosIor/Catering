<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-28 18:52:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-28 18:52:37 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-28 18:52:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 18:52:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 18:53:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 18:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:40:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:51:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:54:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:54:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:55:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:55:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:56:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:56:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 19:56:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:02:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:07:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:11:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:13:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:18:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:19:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:21:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:21:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:25:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:25:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:25:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:28:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:28:47 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\active_waiters_view.php 13
ERROR - 2016-01-28 20:29:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:29:03 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\active_waiters_view.php 13
ERROR - 2016-01-28 20:29:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:29:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:29:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:30:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:48:01 --> Severity: Compile Error --> Cannot redeclare Waiter::ajax_active_waiters() C:\projects\catering.loc\application\controllers\Waiter.php 357
ERROR - 2016-01-28 20:48:33 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' C:\projects\catering.loc\application\controllers\Waiter.php 365
ERROR - 2016-01-28 20:48:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:48:59 --> Severity: Warning --> Creating default object from empty value C:\projects\catering.loc\application\controllers\Waiter.php 366
ERROR - 2016-01-28 20:48:59 --> Severity: Error --> Call to undefined method stdClass::save() C:\projects\catering.loc\application\controllers\Waiter.php 367
ERROR - 2016-01-28 20:49:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:49:56 --> Severity: Warning --> Creating default object from empty value C:\projects\catering.loc\application\controllers\Waiter.php 366
ERROR - 2016-01-28 20:49:56 --> Severity: Error --> Call to undefined method stdClass::save() C:\projects\catering.loc\application\controllers\Waiter.php 367
ERROR - 2016-01-28 20:50:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:51:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:52:29 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 20:52:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 303
ERROR - 2016-01-28 20:53:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:56:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:57:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:57:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 20:58:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:08:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:08:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:12:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:12:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:13:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:13:22 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 21:13:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 303
ERROR - 2016-01-28 21:13:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:13:53 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 21:13:53 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 303
ERROR - 2016-01-28 21:14:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:14:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:18:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:19:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:19:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:19:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:21:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:21:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:23:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:23:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:24:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:24:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:25:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:25:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:25:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:26:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:26:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:27:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:28:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:28:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:31:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:42:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:42:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:42:09 --> Severity: Parsing Error --> syntax error, unexpected 'array_push' (T_STRING), expecting '(' C:\projects\catering.loc\application\controllers\Waiter_new_order.php 351
ERROR - 2016-01-28 21:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:42:22 --> Severity: Parsing Error --> syntax error, unexpected 'array_push' (T_STRING), expecting '(' C:\projects\catering.loc\application\controllers\Waiter_new_order.php 351
ERROR - 2016-01-28 21:42:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:42:45 --> Severity: Error --> Call to undefined method Waiter_new_order::order_model() C:\projects\catering.loc\application\controllers\Waiter_new_order.php 346
ERROR - 2016-01-28 21:43:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:43:09 --> Severity: 4096 --> Object of class User_model could not be converted to string C:\projects\catering.loc\application\controllers\Waiter_new_order.php 346
ERROR - 2016-01-28 21:43:09 --> Severity: Notice --> Object of class User_model to string conversion C:\projects\catering.loc\application\controllers\Waiter_new_order.php 346
ERROR - 2016-01-28 21:43:09 --> Severity: Notice --> Undefined variable: Object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 346
ERROR - 2016-01-28 21:43:09 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 346
ERROR - 2016-01-28 21:43:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:43:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2'
AND `deleted_at` IS NULL' at line 4 - Invalid query: SELECT *
FROM `orders`
WHERE `payment_status` = 'pending'
AND user_record_id IS NOT '2'
AND `deleted_at` IS NULL
ERROR - 2016-01-28 21:44:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:44:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:45:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ''2'
AND `deleted_at` IS NULL' at line 4 - Invalid query: SELECT *
FROM `orders`
WHERE `payment_status` = 'pending'
AND user_record_id IS '2'
AND `deleted_at` IS NULL
ERROR - 2016-01-28 21:45:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:46:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:47:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '2
AND `deleted_at` IS NULL' at line 4 - Invalid query: SELECT *
FROM `orders`
WHERE `payment_status` = 'pending'
AND user_record_id IS NOT 2
AND `deleted_at` IS NULL
ERROR - 2016-01-28 21:49:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:49:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:58:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:58:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 21:58:55 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 21:58:55 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 309
ERROR - 2016-01-28 22:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-28 22:01:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-28 22:01:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:02:35 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 22:02:35 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 314
ERROR - 2016-01-28 22:03:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:03:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:03:45 --> Severity: Notice --> Undefined property: CI_Loader::$websocket_messages_lib C:\projects\catering.loc\application\controllers\Waiter_new_order.php 311
ERROR - 2016-01-28 22:03:45 --> Severity: Error --> Call to a member function waiter_order_updated_to_waiter() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 311
ERROR - 2016-01-28 22:04:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:04:15 --> Severity: Error --> Call to undefined method CI_Loader::waiter_order_updated_to_waiter() C:\projects\catering.loc\application\controllers\Waiter_new_order.php 311
ERROR - 2016-01-28 22:04:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:05:02 --> Severity: Error --> Call to undefined method CI_Loader::waiter_order_updated_to_waiter() C:\projects\catering.loc\application\controllers\Waiter_new_order.php 311
ERROR - 2016-01-28 22:05:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:05:51 --> Severity: Notice --> Undefined property: CI_Loader::$library C:\projects\catering.loc\application\controllers\Waiter_new_order.php 307
ERROR - 2016-01-28 22:05:51 --> Severity: Error --> Class name must be a valid object or a string C:\projects\catering.loc\application\controllers\Waiter_new_order.php 307
ERROR - 2016-01-28 22:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:07:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:07:42 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-28 22:07:42 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 314
ERROR - 2016-01-28 22:12:40 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2016-01-28 22:12:44 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2016-01-28 22:13:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:14:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:16:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-28 22:17:24 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-28 22:18:37 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 32
ERROR - 2016-01-28 22:18:37 --> 404 Page Not Found: Faviconico/index
