<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-30 15:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-30 17:49:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-30 17:49:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-30 18:38:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:39:11 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:40:04 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:40:09 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:41:34 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:41:35 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:41:43 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:41:44 --> 404 Page Not Found: Waiter_layout_mobile_view/index
ERROR - 2015-11-30 18:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:42:17 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-11-30 18:42:19 --> 404 Page Not Found: Cataloguephp/index
ERROR - 2015-11-30 18:44:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:46:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:46:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:46:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:46:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:47:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:47:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:48:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:48:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:48:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:48:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:49:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:49:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:49:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:56:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:58:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:58:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:58:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:58:51 --> 404 Page Not Found: Cataloguephp/index
ERROR - 2015-11-30 18:59:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 18:59:57 --> 404 Page Not Found: Cataloguephp/index
ERROR - 2015-11-30 19:00:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:01:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:02:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:02:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:04:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:04:48 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:05:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:05:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:07:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:07:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:07:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:07:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:08:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:08:17 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:08:17 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\waiter\catalogue.php 22
ERROR - 2015-11-30 19:08:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\catalogue.php 22
ERROR - 2015-11-30 19:08:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:08:30 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:10:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:10:17 --> Severity: 4096 --> Object of class Product_category_model could not be converted to string C:\projects\catering.loc\application\views\waiter\catalogue.php 32
ERROR - 2015-11-30 19:10:17 --> Severity: Notice --> Object of class Product_category_model to string conversion C:\projects\catering.loc\application\views\waiter\catalogue.php 32
ERROR - 2015-11-30 19:10:17 --> Severity: Notice --> Undefined variable: Object C:\projects\catering.loc\application\views\waiter\catalogue.php 32
ERROR - 2015-11-30 19:10:17 --> Severity: Error --> Call to a member function products() on null C:\projects\catering.loc\application\views\waiter\catalogue.php 32
ERROR - 2015-11-30 19:10:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:10:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:11:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:12:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:12:30 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:13:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:13:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:14:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:14:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:14:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:14:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:16:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:16:30 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:16:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:16:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:24:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:24:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:24:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:24:23 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:24:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:24:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:26:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:26:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:26:51 --> 404 Page Not Found: Panel-right2html/index
ERROR - 2015-11-30 19:26:52 --> 404 Page Not Found: Panel-right3html/index
ERROR - 2015-11-30 19:39:07 --> 404 Page Not Found: Images/icons
ERROR - 2015-11-30 19:39:07 --> 404 Page Not Found: Images/shop_thumb1.jpg
ERROR - 2015-11-30 19:39:07 --> 404 Page Not Found: Images/icons
ERROR - 2015-11-30 19:39:07 --> 404 Page Not Found: Images/shop_thumb2.jpg
ERROR - 2015-11-30 19:39:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:39:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:41:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:41:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:41:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:41:53 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:42:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:42:12 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:43:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:43:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:51:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:51:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:53:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:53:07 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:53:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:55:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:55:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:55:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:55:51 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:56:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:56:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:56:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:57:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:57:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:59:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:59:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 19:59:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 19:59:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:00:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:02:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:02:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:03:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:03:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:03:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:03:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:04:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:04:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:04:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:04:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:04:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:04:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:07:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:07:48 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:08:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:08:07 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:08:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:08:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:09:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:09:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:09:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:09:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:09:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:10:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-30 20:10:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:10:55 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\controllers\Orders.php 27
ERROR - 2015-11-30 20:11:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:12:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:12:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:15:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:15:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:15:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:16:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:17:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:17:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:18:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:18:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:19:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:20:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:21:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:21:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:21:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:22:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:23:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:23:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:25:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:25:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:26:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:27:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:28:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:28:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:32:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:32:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:33:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:34:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:35:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:35:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:36:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:37:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:37:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:39:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:40:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:41:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:41:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:41:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:42:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:42:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:42:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:44:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:44:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:45:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:46:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:46:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:46:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:47:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:47:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:48:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:49:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:49:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:50:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:51:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:51:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:52:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:52:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:52:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:53:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:54:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:59:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:59:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 20:59:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:00:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:00:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:01:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:01:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:02:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:02:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:03:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:03:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:04:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:04:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:05:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:05:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:07:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:07:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:08:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:09:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:09:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:11:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:11:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:13:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:13:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-30 21:16:19 --> 404 Page Not Found: Assets/plugins
