<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-04-08 13:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-04-08 13:19:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-04-08 13:19:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-04-08 13:19:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-04-08 13:19:43 --> 404 Page Not Found: Assets/plugins
