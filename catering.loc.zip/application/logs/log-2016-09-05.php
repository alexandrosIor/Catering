<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-05 22:44:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-05 22:44:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-05 22:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-05 22:44:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-05 22:48:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-05 22:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-05 22:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-05 23:21:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-05 23:21:19 --> 404 Page Not Found: Assets/plugins
