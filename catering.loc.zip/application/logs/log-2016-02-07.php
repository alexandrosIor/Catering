<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-07 14:58:39 --> 404 Page Not Found: Browserconfigxml/index
