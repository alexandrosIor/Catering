<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-09 00:04:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-09 00:36:26 --> 404 Page Not Found: Faviconico/index
