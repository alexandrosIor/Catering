<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-19 16:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-19 16:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:53:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:53:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:53:28 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-19 16:53:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:54:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:56:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 16:59:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-19 17:00:40 --> 404 Page Not Found: Assets/plugins
