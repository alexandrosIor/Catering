<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-10 13:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:04:18 --> Non-existent class: Authenticate_lib
ERROR - 2015-11-10 13:04:22 --> Non-existent class: Authenticate_lib
ERROR - 2015-11-10 13:04:32 --> Non-existent class: Authenticate_lib
ERROR - 2015-11-10 13:07:23 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 13:07:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:07:38 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 13:07:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:07:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:07:52 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 13:09:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:09:37 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 13:10:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:10:21 --> Non-existent class: Authenticate_lib
ERROR - 2015-11-10 13:11:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:11:06 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 13:12:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:12:31 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\xampp\htdocs\catering.loc\system\core\Loader.php 314
ERROR - 2015-11-10 13:13:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:13:12 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\xampp\htdocs\catering.loc\system\core\Loader.php 314
ERROR - 2015-11-10 13:13:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:13:54 --> Severity: error --> Exception: Unable to locate the model you have specified: User_model C:\xampp\htdocs\catering.loc\system\core\Loader.php 314
ERROR - 2015-11-10 13:24:31 --> Severity: Notice --> Undefined variable: datatime_now C:\xampp\htdocs\catering.loc\application\migrations\20151101000000_Initial.php 57
ERROR - 2015-11-10 13:24:31 --> Severity: Error --> Call to a member function format() on null C:\xampp\htdocs\catering.loc\application\migrations\20151101000000_Initial.php 57
ERROR - 2015-11-10 13:24:36 --> Severity: Notice --> Undefined variable: datatime_now C:\xampp\htdocs\catering.loc\application\migrations\20151101000000_Initial.php 57
ERROR - 2015-11-10 13:24:36 --> Severity: Error --> Call to a member function format() on null C:\xampp\htdocs\catering.loc\application\migrations\20151101000000_Initial.php 57
ERROR - 2015-11-10 13:25:15 --> Query error: Unknown column 'store_record_ids' in 'field list' - Invalid query: INSERT INTO `users` (`email`, `insert_at`, `password`, `role`, `store_record_ids`) VALUES ('admin@catering.gr','2015-11-10 12:25:15','admin','admin',NULL)
ERROR - 2015-11-10 13:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:29:51 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:29:51 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:31:54 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:31:54 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:32:06 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:32:06 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:35:12 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:35:12 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:35:14 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:35:14 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:36:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:36:08 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:36:08 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:36:23 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:36:23 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:17 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:17 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:37:25 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:25 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:37:31 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:37:31 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 13:40:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:40:20 --> Severity: Notice --> Undefined property: Login::$authenticate C:\xampp\htdocs\catering.loc\application\controllers\Login.php 23
ERROR - 2015-11-10 13:40:20 --> Severity: Error --> Call to a member function login() on null C:\xampp\htdocs\catering.loc\application\controllers\Login.php 23
ERROR - 2015-11-10 13:40:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:40:46 --> Severity: Notice --> Undefined property: Login::$authenticate C:\xampp\htdocs\catering.loc\application\controllers\Login.php 23
ERROR - 2015-11-10 13:40:46 --> Severity: Error --> Call to a member function login() on null C:\xampp\htdocs\catering.loc\application\controllers\Login.php 23
ERROR - 2015-11-10 13:41:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:41:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:43:48 --> 404 Page Not Found: Store_layout_view/index
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:46:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:47:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:48:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:43 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:43 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:43 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:49:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:49:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:50:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:51:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 13:51:59 --> 404 Page Not Found: Store/login.html
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:52:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 13:53:05 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:00:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 14:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 14:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 14:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 14:02:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 14:03:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:03:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:04:42 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:04:42 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:04:42 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:05:17 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:05:17 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:05:17 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:05:27 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:05:27 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:05:27 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:05:46 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:05:46 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:05:46 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:05:54 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:05:54 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:05:54 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:07:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:07:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:07:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:07:08 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:07:08 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 19
ERROR - 2015-11-10 14:07:08 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 23
ERROR - 2015-11-10 14:07:19 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:07:19 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:07:19 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:08:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:08:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:08:04 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:08:05 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:08:05 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:08:05 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:08:35 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:08:35 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:08:35 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:09:33 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:09:33 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:09:33 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:11:13 --> Severity: Error --> Call to undefined method CI_Session::decode() C:\xampp\htdocs\catering.loc\application\controllers\main.php 14
ERROR - 2015-11-10 14:12:52 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:12:52 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:12:52 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:13:14 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:13:14 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:13:14 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:16:45 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:16:45 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:16:45 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:16:48 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:16:48 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:16:48 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:16:59 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:16:59 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:16:59 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:17:00 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:17:00 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 20
ERROR - 2015-11-10 14:17:00 --> Severity: Warning --> Illegal string offset 'role' C:\xampp\htdocs\catering.loc\application\controllers\main.php 24
ERROR - 2015-11-10 14:24:19 --> Severity: Warning --> unserialize() expects parameter 1 to be string, object given C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 26
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:24:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:17 --> Severity: Warning --> unserialize() expects parameter 1 to be string, object given C:\xampp\htdocs\catering.loc\application\controllers\main.php 14
ERROR - 2015-11-10 14:25:17 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:25:27 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:25:41 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:25:46 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:26:28 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:26:32 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:32 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:32 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:26:35 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 16
ERROR - 2015-11-10 14:27:24 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:27:25 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:42:30 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:42:40 --> Severity: Notice --> Main::index(): The script tried to execute a method or access a property of an incomplete object. Please ensure that the class definition &quot;User_model&quot; of the object you are trying to operate on was loaded _before_ unserialize() gets called or provide a __autoload() function to load the class definition  C:\xampp\htdocs\catering.loc\application\controllers\main.php 15
ERROR - 2015-11-10 14:43:51 --> Severity: Notice --> Undefined property: Main::$ci C:\xampp\htdocs\catering.loc\application\controllers\main.php 12
ERROR - 2015-11-10 14:43:51 --> Severity: Notice --> Trying to get property of non-object C:\xampp\htdocs\catering.loc\application\controllers\main.php 12
ERROR - 2015-11-10 14:43:52 --> Severity: Error --> Call to a member function model() on null C:\xampp\htdocs\catering.loc\application\controllers\main.php 12
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:44:06 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:48:00 --> 404 Page Not Found: Store/profile.html
ERROR - 2015-11-10 14:49:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:26 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:26 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:44 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:44 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:44 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:44 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:45 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:45 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:45 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:49:59 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:54:29 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:29 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:29 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:54:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:54:46 --> Unable to load the requested class: Authenticate
ERROR - 2015-11-10 14:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:08 --> Severity: Notice --> Undefined property: Logout::$authenticate C:\xampp\htdocs\catering.loc\application\controllers\Logout.php 12
ERROR - 2015-11-10 14:55:08 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\controllers\Logout.php 12
ERROR - 2015-11-10 14:55:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 14:55:57 --> 404 Page Not Found: Store/index.html
ERROR - 2015-11-10 14:55:59 --> Severity: Notice --> Undefined property: Store::$authenticate C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 14:55:59 --> Severity: Error --> Call to a member function logout() on null C:\xampp\htdocs\catering.loc\application\core\MY_Controller.php 18
ERROR - 2015-11-10 14:59:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:00:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:02:03 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:04:42 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:06:49 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:10:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:10:38 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:10:38 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:10:38 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:10:38 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:11:09 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:11:09 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:11:46 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:11:46 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 15:12:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:12:33 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:29 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:29 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:13:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:14:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:14:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:22:09 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:09 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:09 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:10 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:22:10 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:22:57 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:57 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:57 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:22:57 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:22:57 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:23:01 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:01 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:01 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:02 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 15:23:30 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:30 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:30 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:23:30 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:24:37 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:24:37 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:24:37 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:24:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:24:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:25:20 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:25:54 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:25:54 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:26:39 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:26:39 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:10 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:27:10 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:27:10 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:27:11 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 15:27:43 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:43 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:43 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:43 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:43 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:53 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:53 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:53 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:27:54 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:54 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:27:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:27:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:28:02 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:28:02 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:28:02 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 93
ERROR - 2015-11-10 15:28:02 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:28:02 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:28:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:28:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:28:35 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:28:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:29:24 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:29:24 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:29:24 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:30:17 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:30:17 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:30:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:30:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:30:22 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:30:22 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:30:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:30:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:30:23 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:00 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 92
ERROR - 2015-11-10 15:31:00 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:31:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:31:10 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 92
ERROR - 2015-11-10 15:31:10 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:10 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:31:24 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 92
ERROR - 2015-11-10 15:31:24 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:25 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:35 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:35 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:45 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:45 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:32:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:32:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:37:36 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:37:36 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:37:36 --> Severity: Notice --> Undefined variable: menu_item C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:37:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:37:37 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:37:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:37:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:37:45 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 90
ERROR - 2015-11-10 15:37:52 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 302
ERROR - 2015-11-10 15:38:04 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 302
ERROR - 2015-11-10 15:38:25 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 302
ERROR - 2015-11-10 15:38:48 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:38:48 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:38:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:38:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:39:01 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:39:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:04 --> 404 Page Not Found: Store/store
ERROR - 2015-11-10 15:39:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:17 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:39:17 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:39:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:18 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:39:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:39:26 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:48:44 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 313
ERROR - 2015-11-10 15:49:34 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:49:34 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:51:17 --> Severity: Parsing Error --> syntax error, unexpected '?>' C:\xampp\htdocs\catering.loc\application\views\store_layout_view.php 91
ERROR - 2015-11-10 15:51:35 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:51:35 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:51:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:51:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:52:57 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:52:57 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:52:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:52:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:53:12 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:53:12 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:53:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:53:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:55:38 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:55:39 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:55:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:55:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:55:40 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:55:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:57:22 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:57:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:57:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:58:48 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:58:48 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:58:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:59:26 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:59:26 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:59:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:59:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:59:58 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 15:59:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 15:59:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:00:08 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:00:08 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:00:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:00:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:02:18 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:02:18 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:02:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:02:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:02:36 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:02:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:02:41 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:06:27 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:06:50 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:06:50 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:07:34 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:07:34 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:11:10 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:11:15 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:11:19 --> 404 Page Not Found: Store/assets
ERROR - 2015-11-10 16:11:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:11:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:12:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:12:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 16:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:32:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:32:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:33:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:33:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:34:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:37:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 16:37:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:37:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:40:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:42:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:42:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:44:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:45:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 16:46:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 16:46:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:47:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:47:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:47:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:47:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:47:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:49:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-10 16:52:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:53:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-10 16:54:06 --> 404 Page Not Found: Assets/plugins
