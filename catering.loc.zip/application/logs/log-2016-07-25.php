<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-07-25 13:36:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-07-25 13:39:10 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-07-25 13:39:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-07-25 13:39:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-07-25 13:40:21 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-07-25 13:40:22 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-07-25 13:41:08 --> 404 Page Not Found: Assets/plugins
