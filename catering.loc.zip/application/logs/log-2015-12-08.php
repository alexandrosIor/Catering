<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-08 18:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-08 18:12:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:12:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:13:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:15:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:16:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:17:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:18:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:18:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:18:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:26:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:27:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:28:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:29:41 --> 404 Page Not Found: Users/update_user
ERROR - 2015-12-08 18:36:09 --> Severity: Notice --> Undefined index: product_record_id C:\projects\catering.loc\application\controllers\Catalogue.php 240
ERROR - 2015-12-08 18:36:09 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Catalogue.php 249
ERROR - 2015-12-08 18:36:17 --> Severity: Notice --> Undefined index: product_record_id C:\projects\catering.loc\application\controllers\Catalogue.php 240
ERROR - 2015-12-08 18:36:17 --> Severity: Error --> Call to a member function un_delete() on null C:\projects\catering.loc\application\controllers\Catalogue.php 245
ERROR - 2015-12-08 18:36:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:36:22 --> Severity: Notice --> Undefined index: product_record_id C:\projects\catering.loc\application\controllers\Catalogue.php 240
ERROR - 2015-12-08 18:36:22 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Catalogue.php 249
ERROR - 2015-12-08 18:37:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:37:17 --> 404 Page Not Found: User/ajax_change_status
ERROR - 2015-12-08 18:37:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:51:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:51:12 --> Severity: Error --> Call to undefined method Users::get_user_roles() C:\projects\catering.loc\application\controllers\Users.php 64
ERROR - 2015-12-08 18:51:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:51:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:52:26 --> 404 Page Not Found: User/ajax_save_user
ERROR - 2015-12-08 18:52:42 --> 404 Page Not Found: User/ajax_save_user
ERROR - 2015-12-08 18:52:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:53:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:53:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:53:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:54:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:54:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:55:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:56:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:58:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:58:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:58:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:58:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:58:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:59:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:59:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:59:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:59:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 18:59:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:05:31 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:25:54 --> 404 Page Not Found: Catalasd/index
ERROR - 2015-12-08 19:29:05 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:29:15 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:37:44 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:37:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:37:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:38:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:39:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:41:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:41:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:47:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:47:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:51:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:53:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:54:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:21 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:55:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:43 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 19:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:55:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:56:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 19:59:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:00:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:01:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:02:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:02:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:03:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:03:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:04:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:06:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:07:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:07:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:08:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:08:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:08:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:08:29 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:08:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:11:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:12:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:12:21 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:12:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:12:24 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:12:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:13:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:13:46 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:13:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:13:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:15:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:15:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:16:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:17:04 --> Severity: Notice --> Undefined property: Users::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:17:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:17:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:17:38 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:17:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:18:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:18:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:18:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:18:50 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-08 20:18:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:23:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:25:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:26:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:26:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:27:14 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING) C:\projects\catering.loc\application\controllers\Catalogue.php 213
ERROR - 2015-12-08 20:27:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:27:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:28:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:28:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-08 20:28:30 --> 404 Page Not Found: Assets/plugins
