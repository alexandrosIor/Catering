<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-12 19:47:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-12 20:05:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:33:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:33:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:33:58 --> Severity: Error --> Call to undefined function get_seconds_diff_from_datetimes() C:\projects\catering.loc\application\controllers\Orders.php 178
ERROR - 2016-01-12 20:34:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:34:35 --> Severity: Error --> Call to undefined function get_seconds_diff_from_datetimes() C:\projects\catering.loc\application\controllers\Orders.php 178
ERROR - 2016-01-12 20:34:58 --> Severity: Notice --> Undefined property: Orders::$firtsname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-12 20:34:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:34:58 --> Severity: Error --> Call to undefined method Order_model::seconds_to_time() C:\projects\catering.loc\application\controllers\Orders.php 187
ERROR - 2016-01-12 20:35:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:35:13 --> Severity: Notice --> Undefined property: Orders::$firtname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-12 20:35:13 --> Severity: Error --> Call to undefined method Order_model::seconds_to_time() C:\projects\catering.loc\application\controllers\Orders.php 187
ERROR - 2016-01-12 20:35:28 --> Severity: Error --> Call to undefined method Order_model::seconds_to_time() C:\projects\catering.loc\application\controllers\Orders.php 187
ERROR - 2016-01-12 20:35:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:35:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:35:47 --> Severity: Error --> Call to undefined method Order_model::total_price() C:\projects\catering.loc\application\controllers\Orders.php 188
ERROR - 2016-01-12 20:36:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:36:32 --> Severity: Notice --> Undefined property: Orders::$total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-12 20:37:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:38:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:38:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:38:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:39:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:42:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:43:21 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\projects\catering.loc\application\controllers\Orders.php 189
ERROR - 2016-01-12 20:43:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:43:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:43:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 20:45:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:00:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:00:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:00:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:01:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:02:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:03:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:05:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:06:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:07:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:08:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:09:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:11:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:17:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:18:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:20:23 --> Severity: 4096 --> Object of class Order_model could not be converted to string C:\projects\catering.loc\application\controllers\Orders.php 144
ERROR - 2016-01-12 21:20:23 --> Severity: Notice --> Object of class Order_model to string conversion C:\projects\catering.loc\application\controllers\Orders.php 144
ERROR - 2016-01-12 21:20:23 --> Severity: Notice --> Undefined property: Orders::$Object C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-12 21:20:23 --> Severity: Error --> Call to a member function calculate_total_cost() on null C:\projects\catering.loc\application\controllers\Orders.php 144
ERROR - 2016-01-12 21:21:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:31:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:31:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:31:21 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-12 21:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:31:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:32:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:41:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:41:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:42:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:43:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:43:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:43:30 --> 404 Page Not Found: Waiter/ajax_load_orders
ERROR - 2016-01-12 21:43:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:54:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:55:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 21:55:26 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 21:57:39 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 22:30:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:30:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:31:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:34:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:34:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-12 22:34:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-12 22:35:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:35:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:39:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:40:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:40:17 --> Query error: Unknown column 'order_completed' in 'field list' - Invalid query: UPDATE `order_products` SET `order_record_id` = '4', `product_record_id` = '20', `quantity` = '1', `comments` = NULL, `record_id` = '6', `insert_at` = '2016-01-12 20:12:53', `update_at` = '2016-01-12 20:12:53', `deleted_at` = NULL, `order_completed` = 1
WHERE `record_id` = '6'
ERROR - 2016-01-12 22:40:19 --> Query error: Unknown column 'order_completed' in 'field list' - Invalid query: UPDATE `order_products` SET `order_record_id` = '4', `product_record_id` = '19', `quantity` = '1', `comments` = NULL, `record_id` = '7', `insert_at` = '2016-01-12 20:12:54', `update_at` = '2016-01-12 20:12:54', `deleted_at` = NULL, `order_completed` = 1
WHERE `record_id` = '7'
ERROR - 2016-01-12 22:42:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:42:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:44:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:45:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:46:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:47:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:47:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:48:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:50:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:50:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:52:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:53:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:54:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:54:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 22:54:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:00:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:01:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:03:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:05:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:07:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:08:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:08:34 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:08:36 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:08:38 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:09:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:11:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:30:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:30:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:30:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:32:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:32:50 --> Severity: Error --> Call to undefined method Waiter::order_model() C:\projects\catering.loc\application\controllers\Waiter.php 156
ERROR - 2016-01-12 23:33:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:33:24 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:33:29 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:33:34 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:33:45 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:34:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:34:51 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:36:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:36:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:36:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:36:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:37:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:38:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:38:15 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:38:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:38:50 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:38:53 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:38:59 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:39:02 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:39:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:39:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:40:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:40:23 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:26 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:28 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:31 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:32 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:34 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:36 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:40:38 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:41:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:41:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:41:22 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:41:25 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:41:28 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:41:31 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:41:34 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-12 23:43:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:44:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:44:21 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:44:26 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:44:28 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:44:32 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:44:33 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
ERROR - 2016-01-12 23:45:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:46:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:51:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:56:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-12 23:56:26 --> Severity: Notice --> Undefined variable: order_total_price C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 10
