<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-25 15:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-25 15:10:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:12:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:13:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:13:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:13:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:15:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-25 15:16:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:16:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:17:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:20:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-25 15:21:38 --> 404 Page Not Found: Assets/plugins
