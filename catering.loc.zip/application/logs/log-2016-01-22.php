<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-22 20:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-22 20:51:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:51:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:52:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:52:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:52:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:52:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:53:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:53:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:53:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:54:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:55:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:55:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:56:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-22 20:56:09 --> 404 Page Not Found: Assets/plugins
