<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-10-26 13:34:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-26 13:42:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:42:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:42:15 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-10-26 13:42:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:43:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:43:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:45:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:56:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 13:58:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 14:06:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-10-26 14:06:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-10-26 14:06:19 --> 404 Page Not Found: Assets/plugins
