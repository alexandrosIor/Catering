<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-25 21:03:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-02-25 21:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 21:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 21:20:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 21:20:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 21:20:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 21:20:22 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-02-25 22:23:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 22:23:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-02-25 23:42:21 --> 404 Page Not Found: Assets/plugins
