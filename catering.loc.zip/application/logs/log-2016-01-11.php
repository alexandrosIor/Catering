<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-11 15:17:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-11 15:17:42 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2016-01-11 15:18:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-11 15:18:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-11 15:18:08 --> 404 Page Not Found: Img/icon.png
