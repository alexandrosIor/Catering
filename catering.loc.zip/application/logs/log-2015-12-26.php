<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-26 12:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-26 13:05:40 --> Severity: Notice --> Undefined property: Store::$order C:\projects\catering.loc\application\controllers\Store.php 25
ERROR - 2015-12-26 13:05:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 25
ERROR - 2015-12-26 13:05:40 --> Severity: Error --> Call to a member function get_records() on null C:\projects\catering.loc\application\controllers\Store.php 25
ERROR - 2015-12-26 13:09:26 --> Severity: Notice --> Undefined property: Store::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 13:09:26 --> Severity: Notice --> Undefined property: Store::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 13:09:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\dashboard.php 10
ERROR - 2015-12-26 13:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-26 13:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-26 13:10:42 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-26 13:10:42 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-26 13:11:25 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-26 13:11:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:11:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:27:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:27:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:27:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:27:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:28:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:28:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:29:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:29:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:30:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:30:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:35:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:41:27 --> Severity: Parsing Error --> syntax error, unexpected '$time' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Store.php 29
ERROR - 2015-12-26 13:45:08 --> Severity: Notice --> Undefined variable: elapsed_days C:\projects\catering.loc\application\controllers\Store.php 32
ERROR - 2015-12-26 13:45:08 --> Severity: Notice --> Undefined variable: elapsed_days C:\projects\catering.loc\application\controllers\Store.php 32
ERROR - 2015-12-26 13:50:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:55:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:55:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:56:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:57:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 13:59:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:00:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:00:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:00:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:01:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:01:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:02:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:02:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:03:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:04:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:04:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:04:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:07:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:14:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:14:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:15:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:16:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:17:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:17:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:18:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:18:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:19:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:19:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:20:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:21:25 --> Severity: Error --> Call to undefined function time_to_seconds() C:\projects\catering.loc\application\controllers\Store.php 34
ERROR - 2015-12-26 14:23:22 --> Severity: Error --> Call to undefined function time_to_seconds() C:\projects\catering.loc\application\controllers\Store.php 34
ERROR - 2015-12-26 14:24:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:25:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:25:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:31:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:31:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:33:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:33:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:33:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:33:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 14:39:22 --> Severity: Warning --> usort() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Store.php 41
ERROR - 2015-12-26 14:40:07 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\projects\catering.loc\application\controllers\Store.php 39
ERROR - 2015-12-26 14:40:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:13:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:15:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:15:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:16:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:17:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:17:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:18:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:18:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:18:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:18:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:19:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:19:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:19:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:19:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:19:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:20:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Undefined property: Store::$product_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 15:25:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Store.php 38
ERROR - 2015-12-26 15:25:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:26:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:50:04 --> Query error: Unknown column 'user_record_id' in 'where clause' - Invalid query: SELECT *
FROM `users`
WHERE `user_record_id` = '2'
AND `deleted_at` IS NULL
ERROR - 2015-12-26 15:50:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:50:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:50:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:50:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:51:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:51:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:51:38 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:51:38 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\orders_view.php 19
ERROR - 2015-12-26 15:52:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 35
ERROR - 2015-12-26 15:52:57 --> Severity: Notice --> Undefined index: lastname C:\projects\catering.loc\application\controllers\Orders.php 35
ERROR - 2015-12-26 15:53:20 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 35
ERROR - 2015-12-26 15:58:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:59:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:59:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 15:59:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:00:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:01:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:01:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:05:41 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\store\orders\orders_view.php 23
ERROR - 2015-12-26 16:05:41 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\store\orders\orders_view.php 23
ERROR - 2015-12-26 16:05:54 --> Severity: Notice --> Undefined variable: modal_title C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 3
ERROR - 2015-12-26 16:07:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:07:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:08:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:08:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:10:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:11:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:14:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:14:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:15:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:15:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:15:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:17:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:19:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:20:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:20:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:20:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 16:20:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:06:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-26 18:11:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:13:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:13:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:14:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:15:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:15:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:15:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:16:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:16:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:16:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:16:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:18:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:20:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:21:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:23:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:24:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:26:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:31:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:34:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:36:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:37:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:37:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:38:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:38:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:38:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:39:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:39:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:40:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:41:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:42:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:43:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:43:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:43:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:44:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:44:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:44:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 18:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:00:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:01:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:02:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:02:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:03:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:03:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:03:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:11:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:11:53 --> Severity: Error --> Call to undefined method Orders::get_records() C:\projects\catering.loc\application\controllers\Orders.php 61
ERROR - 2015-12-26 19:12:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:13:20 --> Severity: Compile Error --> Cannot use [] for reading C:\projects\catering.loc\application\controllers\Orders.php 62
ERROR - 2015-12-26 19:16:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:16:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:16:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:16:15 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:19:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:19:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:19:49 --> Severity: Notice --> Undefined index: Θαλασσινά C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:19:49 --> Severity: Notice --> Undefined index: Ορεκτικά κρύα C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:19:49 --> Severity: Notice --> Undefined index: Χωρις αλκοόλ C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:20:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:20:30 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:20:30 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:20:30 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:21:07 --> Severity: Notice --> Undefined index: Θαλασσινά C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:07 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:07 --> Severity: Notice --> Undefined index: Ορεκτικά κρύα C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:07 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:07 --> Severity: Notice --> Undefined index: Χωρις αλκοόλ C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:07 --> Severity: Warning --> array_merge(): Argument #1 is not an array C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:32 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:21:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:22:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:22:11 --> Severity: Notice --> Undefined index: θαλασσινά C:\projects\catering.loc\application\controllers\Orders.php 69
ERROR - 2015-12-26 19:22:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:23:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:24:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:24:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:24:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:24:14 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Orders.php 66
ERROR - 2015-12-26 19:25:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:28:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:28:54 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ',' or ';' C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 29
ERROR - 2015-12-26 19:29:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:29:15 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:29:15 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:29:15 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:29:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:29:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:29:49 --> Severity: Error --> Cannot use object of type Order_product_model as array C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 31
ERROR - 2015-12-26 19:29:52 --> Severity: Error --> Cannot use object of type Order_product_model as array C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 31
ERROR - 2015-12-26 19:30:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:30:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:30:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:30:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 32
ERROR - 2015-12-26 19:31:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:32:22 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting ',' or ';' C:\projects\catering.loc\application\controllers\Orders.php 71
ERROR - 2015-12-26 19:32:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:38:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:44:29 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:44:29 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:44:29 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:45:07 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:45:07 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:45:07 --> Severity: Notice --> Undefined property: Orders::$name C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-26 19:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:50:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:50:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:52:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:52:15 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 39
ERROR - 2015-12-26 19:52:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:52:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:53:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:54:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:54:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:55:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:56:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:57:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:57:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 19:59:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:00:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 11
ERROR - 2015-12-26 20:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 11
ERROR - 2015-12-26 20:00:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 11
ERROR - 2015-12-26 20:00:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:01:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:05 --> Severity: Notice --> Undefined variable: key C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 13
ERROR - 2015-12-26 20:01:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:13:31 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:13:31 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:13:31 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:00 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:00 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:00 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:14 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:14 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:14 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:42 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:42 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:14:42 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:10 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:10 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:10 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:51 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:51 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:15:51 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:02 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:02 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:02 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:32 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:32 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:16:32 --> Severity: Notice --> Undefined variable: count C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 20
ERROR - 2015-12-26 20:42:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:42:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:43:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 20:44:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:09:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:14:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-26 21:18:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:18:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:19:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:30:46 --> Severity: Error --> Call to undefined method Orders::get_record() C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 21:30:58 --> Severity: Error --> Call to undefined method Orders::get_record() C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 21:31:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:31:16 --> Severity: Error --> Function name must be a string C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 21:32:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:32:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 21:32:26 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 21:32:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:33:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:33:20 --> Severity: Error --> Call to undefined method Order_product_model::undelete() C:\projects\catering.loc\application\controllers\Orders.php 95
ERROR - 2015-12-26 21:33:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:35:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:35:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:36:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:36:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:36:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:38:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:38:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:38:40 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 21:38:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 21:38:40 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 21:38:42 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 21:38:42 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 21:38:42 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 21:39:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:39:11 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 36
ERROR - 2015-12-26 21:39:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:39:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:39:39 --> Severity: Error --> Call to undefined method Order_product_model::undelete() C:\projects\catering.loc\application\controllers\Orders.php 95
ERROR - 2015-12-26 21:39:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:39:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:40:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 21:40:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:30:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:31:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:42:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:42:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:42:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:42:54 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:42:54 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:42:54 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:42:56 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:42:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:42:56 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:42:57 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:42:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:42:57 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:42:58 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:42:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:42:58 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:42:59 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:42:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:42:59 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:43:00 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:43:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:43:00 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:43:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:45:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:45:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:46:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:46:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:47:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:48:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:48:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:49:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:49:23 --> Severity: Notice --> Undefined index: order_product_record_id C:\projects\catering.loc\application\controllers\Orders.php 91
ERROR - 2015-12-26 22:49:23 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 93
ERROR - 2015-12-26 22:49:23 --> Severity: Error --> Call to a member function soft_delete() on null C:\projects\catering.loc\application\controllers\Orders.php 99
ERROR - 2015-12-26 22:49:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:50:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:50:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:50:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:51:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:51:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:51:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:52:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:52:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:52:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 22:53:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:04:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:04:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:06:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:06:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:07:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:11:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:13:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:15:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:18:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:18:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:18:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:18:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:19:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:19:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:21:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:22:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:22:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:22:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:23:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:23:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:23:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:24:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:24:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:24:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:24:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:25:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:25:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:26:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:27:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:28:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:29:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:30:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:31:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:32:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:32:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:32:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:32:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:33:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:36:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:36:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:36:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:37:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:37:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:37:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:43:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:43:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:43:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:44:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:46:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:47:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:47:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:48:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:48:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:50:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:50:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:51:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:53:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:54:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:54:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:54:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:55:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:55:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:55:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:56:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:56:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:58:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:59:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-26 23:59:56 --> 404 Page Not Found: Assets/plugins
