<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-10 19:18:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-10 19:53:19 --> 404 Page Not Found: Tables/index
ERROR - 2015-12-10 19:53:37 --> 404 Page Not Found: Tables/index
ERROR - 2015-12-10 19:53:40 --> 404 Page Not Found: Tables/index
ERROR - 2015-12-10 19:53:44 --> 404 Page Not Found: Tables/index
ERROR - 2015-12-10 19:56:26 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 19:56:28 --> 404 Page Not Found: Store_tables/store_table_modal_form
ERROR - 2015-12-10 19:59:46 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:00:27 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:00:37 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:00:45 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:00:51 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:01:02 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:01:57 --> 404 Page Not Found: Assets/js
ERROR - 2015-12-10 20:02:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:02:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:02:26 --> Severity: error --> Exception: C:\projects\catering.loc\application\models/Store_table_model.php exists, but doesn't declare class Store_table_model C:\projects\catering.loc\system\core\Loader.php 306
ERROR - 2015-12-10 20:03:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:08:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:09:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:09:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:11:11 --> Severity: Parsing Error --> syntax error, unexpected '.' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:11:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:12:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:12:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:14:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:14:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:15:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:15:37 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:15:53 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:53 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:53 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:53 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:15:54 --> Severity: Notice --> Use of undefined constant dsa - assumed 'dsa' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:08 --> Severity: 4096 --> Object of class Store_tables could not be converted to string C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:16:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:17:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:17:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:18:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:18:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:19:05 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' C:\projects\catering.loc\application\controllers\Store_tables.php 45
ERROR - 2015-12-10 20:19:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:19:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:20:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:30:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:30:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:32:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:32:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:32:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:33:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:36:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:36:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:41:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:43:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:43:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:43:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:44:06 --> 404 Page Not Found: Store_tables/ajax_store_table
ERROR - 2015-12-10 20:45:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:45:04 --> Severity: Notice --> Undefined property: Store_tables::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-10 20:45:04 --> Query error: Column 'in_use' cannot be null - Invalid query: INSERT INTO `tables` (`caption`, `seats`, `in_use`, `record_id`, `insert_at`, `update_at`, `deleted_at`) VALUES ('dasdasd', '12', NULL, NULL, '2015-12-10 19:45:04', '2015-12-10 19:45:04', NULL)
ERROR - 2015-12-10 20:47:14 --> Query error: Column 'in_use' cannot be null - Invalid query: INSERT INTO `tables` (`caption`, `seats`, `in_use`, `record_id`, `insert_at`, `update_at`, `deleted_at`) VALUES ('dasdasd', '12', NULL, NULL, '2015-12-10 19:47:14', '2015-12-10 19:47:14', NULL)
ERROR - 2015-12-10 20:48:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:48:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:48:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:48:51 --> Severity: Notice --> Undefined property: Store_tables::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-10 20:48:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:48:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:49:35 --> Severity: Notice --> Undefined property: Store_tables::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-10 20:49:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:49:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:49:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:50:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:50:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:50:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:58:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:58:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:58:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:58:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:49 --> Severity: Notice --> Undefined property: Store_tables::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-10 20:59:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 20:59:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 21:00:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 21:00:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-10 21:03:34 --> Query error: Table 'catering.tables' doesn't exist - Invalid query: INSERT INTO `tables` (`caption`, `insert_at`, `seats`) VALUES ('1','2015-12-10 20:03:34','4'), ('2','2015-12-10 20:03:34','6'), ('3','2015-12-10 20:03:34','2'), ('4','2015-12-10 20:03:34','10'), ('5','2015-12-10 20:03:34','4'), ('6','2015-12-10 20:03:34','4'), ('πίσω γωνία','2015-12-10 20:03:34','2'), ('7','2015-12-10 20:03:34','4'), ('8','2015-12-10 20:03:34','6'), ('9','2015-12-10 20:03:34','2'), ('10','2015-12-10 20:03:34','6'), ('11','2015-12-10 20:03:34','4'), ('12','2015-12-10 20:03:34','5'), ('ΜΕΓΑΛΟ ΑΡΙΣΤΕΡΑ','2015-12-10 20:03:34','10'), ('13','2015-12-10 20:03:34','4'), ('14','2015-12-10 20:03:34','5'), ('15','2015-12-10 20:03:34','8')
