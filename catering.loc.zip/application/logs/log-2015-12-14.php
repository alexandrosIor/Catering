<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-14 19:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-14 20:00:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:00:46 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\projects\catering.loc\application\models\Shift_model.php 58
ERROR - 2015-12-14 20:00:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:01:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:01:20 --> Severity: Notice --> Undefined property: Shifts::$lastname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:01:20 --> Severity: Notice --> Undefined property: Shifts::$firstname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:01:20 --> Severity: Notice --> Undefined property: Shifts::$user C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:01:20 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Shift_model.php 49
ERROR - 2015-12-14 20:01:20 --> Severity: Error --> Call to a member function get_record() on null C:\projects\catering.loc\application\models\Shift_model.php 49
ERROR - 2015-12-14 20:04:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:04:57 --> Severity: Notice --> Undefined property: Shifts::$user C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:04:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\models\Shift_model.php 49
ERROR - 2015-12-14 20:04:57 --> Severity: Error --> Call to a member function get_record() on null C:\projects\catering.loc\application\models\Shift_model.php 49
ERROR - 2015-12-14 20:05:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:06:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:06:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:06:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:09:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:09:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:10:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:11:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-14 20:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-14 20:15:40 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-14 20:15:41 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-14 20:15:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:20:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:20:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:21:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:23:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:23:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:24:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:28:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:28:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:29:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:30:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:31:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:32:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:32:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:32:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:33:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:34:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:39:12 --> Severity: Notice --> Undefined property: Shifts::$enddate C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:39:12 --> Severity: Notice --> Undefined property: Shifts::$enddate C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 20:39:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:39:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:44:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:47:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:52:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:52:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:57:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:57:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 20:57:29 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-14 20:57:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:02:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:02:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:05:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:06:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:06:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:06:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:07:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:09:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:09:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:09:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:09:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:10:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:10:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:11:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:11:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:11:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:12:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:13:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:13:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:13:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:14:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:14:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:14:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:16:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:16:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:26:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:26:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:27:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:27:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:27:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:28:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:28:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:29:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:33:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:33:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:34:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:35:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:35:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:36:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:36:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:37:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:37:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:37:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:38:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:39:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:40:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:40:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:40:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:41:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:42:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:43:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:44:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:45:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:47:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:49:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:49:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:51:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:52:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:53:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:56:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:56:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:57:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 21:58:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:01:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:01:47 --> 404 Page Not Found: Orders/ajax_add_product_for_order
ERROR - 2015-12-14 22:04:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:06:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:06:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:08:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:09:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:11:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:12:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:12:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:13:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:15:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:15:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:17:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:19:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:33:53 --> Severity: Notice --> Undefined property: Orders::$5 C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 22:33:53 --> Severity: Notice --> Undefined property: Orders::$4 C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 22:33:53 --> Severity: Error --> Cannot access empty property C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 22:35:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 22:35:36 --> Severity: Notice --> Undefined property: Orders::$3 C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 22:35:36 --> Severity: Error --> Cannot access empty property C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-14 23:06:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:06:58 --> Query error: Unknown column 'order_data' in 'field list' - Invalid query: INSERT INTO `orders` (`table_record_id`, `user_record_id`, `shift_record_id`, `order_data`, `start_datetime`, `end_datetime`, `record_id`, `insert_at`, `update_at`, `deleted_at`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-12-14 22:06:58', '2015-12-14 22:06:58', NULL)
ERROR - 2015-12-14 23:07:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:07:21 --> Query error: Unknown column 'order_data' in 'field list' - Invalid query: INSERT INTO `orders` (`table_record_id`, `user_record_id`, `shift_record_id`, `order_data`, `start_datetime`, `end_datetime`, `record_id`, `insert_at`, `update_at`, `deleted_at`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2015-12-14 22:07:21', '2015-12-14 22:07:21', NULL)
ERROR - 2015-12-14 23:09:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:11:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:11:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:14:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:15:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:15:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:16:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:16:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:18:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:22:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:30:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:32:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:32:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:43:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:43:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:44:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-14 23:48:40 --> 404 Page Not Found: Assets/plugins
