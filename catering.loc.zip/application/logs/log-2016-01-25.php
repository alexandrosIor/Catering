<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-25 20:32:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-25 20:33:12 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-25 20:33:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:33:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:33:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-25 20:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-25 20:43:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:44:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:46:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:57:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 20:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:04:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:04:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:05:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:05:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:05:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:05:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:05:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:06:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:08:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:08:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:09:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:10:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:10:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:10:34 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:10:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 297
ERROR - 2016-01-25 21:11:26 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:11:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 297
ERROR - 2016-01-25 21:11:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:12:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:13:08 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:13:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:13:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:13:29 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:13:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:19:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:19:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:19:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:19:37 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:19:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:19:50 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:19:50 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:20:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:20:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:20:44 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:20:44 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:21:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:21:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:21:28 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:21:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:21:41 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:21:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:22:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:22:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:23:27 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:23:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:24:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:24:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:24:32 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:24:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:25:21 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:25:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:25:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:25:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:25:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:26:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:26:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:26:43 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:26:43 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:26:52 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:26:52 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:28:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:28:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:28:50 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:28:50 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:28:58 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:28:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:29:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:29:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:30:02 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:30:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:30:15 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:30:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:30:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:30:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:31:53 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:31:53 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:32:19 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:32:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:32:45 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:32:45 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:33:11 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:33:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:33:45 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:33:45 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 301
ERROR - 2016-01-25 21:33:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:33:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:36:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:36:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:36:57 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:36:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 302
ERROR - 2016-01-25 21:37:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:37:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:37:24 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:37:24 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 302
ERROR - 2016-01-25 21:37:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:37:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:37:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:37:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:38:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:38:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:38:57 --> Severity: Notice --> Undefined property: Waiter_new_order::$user_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-25 21:38:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 302
ERROR - 2016-01-25 21:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-25 21:40:12 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:40:15 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:40:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-25 21:41:29 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:32 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:35 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-25 21:41:42 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
