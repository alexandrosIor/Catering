<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-03 15:00:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-03 15:00:26 --> 404 Page Not Found: Faviconico/index
