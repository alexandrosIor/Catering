<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-21 18:59:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-21 19:00:47 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-21 19:00:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:00:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:02:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:03:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:03:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:15:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:21:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-21 19:21:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-21 19:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:22:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:22:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:23:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:24:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:27:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:27:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:29:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:30:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:31:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:32:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:32:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:33:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:38:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:40:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:45:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:46:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:46:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:47:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:47:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:48:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:48:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:48:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:49:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:51:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:51:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:52:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:53:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:53:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:57:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 19:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:00:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:01:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:02:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:03:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:04:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:05:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:05:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:06:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:07:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:07:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:08:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:08:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:09:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:09:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:10:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:11:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:12:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:13:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:14:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:15:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:15:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:33 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:33 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:35 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:36 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:36 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:15:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:03 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:04 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:14 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:15 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:25 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:25 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:26 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:26 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:27 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:38 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:38 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:40 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:41 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-21 20:16:41 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 227
ERROR - 2016-01-21 20:16:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:18:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:18:52 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:21:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:21:05 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:21:06 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:21:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:21:13 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:21:13 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:31:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:34:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:37:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:38:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:39:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:40:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:41:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:46:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:49:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:50:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:51:14 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:53:46 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:47 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:48 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:49 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:50 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:50 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:53:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:54:00 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:54:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:54:07 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:54:08 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:55:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:56:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:56:57 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:56:58 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:56:59 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 20:57:28 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:28 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:29 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:29 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:57:31 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:58:29 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:58:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:58:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:58:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 20:58:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:07:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:07:10 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:07:28 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:07:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:07:40 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:07:43 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:11:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:19:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:20:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:20:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:29:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:29:39 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-21 21:29:39 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '6', `user_record_id` = '2', `shift_record_id` = '1', `start_date` = '2016-01-21 20:29:39', `end_date` = NULL, `payment_status` = 'pending', `record_id` = '1', `insert_at` = '2016-01-21 20:29:35', `update_at` = '2016-01-21 20:29:39', `deleted_at` = NULL, `order_products` = NULL
WHERE `record_id` = '1'
ERROR - 2016-01-21 21:31:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:32:16 --> Severity: Notice --> Undefined property: Waiter::$extra_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:39:36 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:36 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:36 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:39:57 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:57 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:39:57 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:40:01 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:40:01 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:40:01 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:40:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:41:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:41:07 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:41:07 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:41:07 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:42:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:42:59 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:42:59 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:42:59 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:18 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:18 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:18 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:20 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:20 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:20 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:43:27 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:27 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:27 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:43:38 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:38 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:43:38 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:46:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:46:26 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 69
ERROR - 2016-01-21 21:46:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:46:44 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:46:46 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:46:49 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:46:51 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:47:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:47:08 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:47:10 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:47:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:47:20 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:47:20 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:49:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:49:01 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:49:03 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:49:05 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:49:23 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:50:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:50:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:50:49 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:51:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:51:59 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:52:02 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:52:05 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:52:09 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:52:15 --> Severity: Notice --> Undefined property: Waiter::$unpaid_products C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:52:17 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 21:52:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:52:55 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:53:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:53:12 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:53:14 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 21:53:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 21:55:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:08:58 --> Severity: Parsing Error --> syntax error, unexpected ''default'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 239
ERROR - 2016-01-21 22:09:01 --> Severity: Parsing Error --> syntax error, unexpected ''default'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 239
ERROR - 2016-01-21 22:09:03 --> Severity: Parsing Error --> syntax error, unexpected ''default'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 239
ERROR - 2016-01-21 22:09:10 --> Severity: Parsing Error --> syntax error, unexpected ''default'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 239
ERROR - 2016-01-21 22:09:16 --> Severity: Parsing Error --> syntax error, unexpected ''default'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 239
ERROR - 2016-01-21 22:11:06 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 32
ERROR - 2016-01-21 22:11:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:11:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:11:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:14:00 --> Severity: Notice --> Undefined property: Waiter::$unpaid_total_price C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-21 22:14:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:15:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:16:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:18:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:19:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:19:59 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 68
ERROR - 2016-01-21 22:19:59 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\waiter\incomplete_order_products_view.php 68
ERROR - 2016-01-21 22:20:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:20:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:20:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:21:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:22:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:24:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:25:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:25:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:25:47 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:25:49 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:26:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:27:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:27:26 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:27:26 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:27:27 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:27:28 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:27:28 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:28:01 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:28:02 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:28:04 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 229
ERROR - 2016-01-21 22:28:08 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-01-21 22:29:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-21 22:32:49 --> 404 Page Not Found: Assets/plugins
