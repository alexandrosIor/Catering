<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-26 17:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-26 17:37:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 17:37:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 17:38:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 17:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 17:38:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 17:38:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 18:09:39 --> Severity: error --> Exception: Unable to locate the model you have specified: Category_model C:\projects\catering.loc\system\core\Loader.php 314
ERROR - 2015-11-26 18:35:39 --> Severity: Error --> Call to undefined method Layout_lib::print_addsitional_js() C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 57
ERROR - 2015-11-26 18:41:05 --> Severity: Notice --> Undefined index: category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 18:42:30 --> Severity: Notice --> Undefined index: category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 18:43:56 --> Severity: Notice --> Undefined variable: produc C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:43:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:43:56 --> Severity: Notice --> Undefined variable: produc C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:43:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:44:09 --> Severity: Notice --> Undefined variable: produc C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:44:09 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:44:09 --> Severity: Notice --> Undefined variable: produc C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:44:09 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\orders\products_modal.php 6
ERROR - 2015-11-26 18:47:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-26 19:05:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-26 19:05:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-26 19:18:42 --> Severity: Notice --> Undefined index: category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:18:56 --> Severity: Notice --> Undefined index: category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:19:01 --> Severity: Notice --> Undefined index: category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:20:42 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:23:44 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:23:48 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:27:50 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:37:43 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:38:01 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:38:10 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:40:58 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:41:41 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:41:43 --> Severity: Notice --> Undefined index: product_category_record_id C:\projects\catering.loc\application\controllers\Orders.php 68
ERROR - 2015-11-26 19:56:54 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 37
ERROR - 2015-11-26 20:16:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0
AND `deleted_at` IS NULL' at line 3 - Invalid query: SELECT *
FROM `product_categories`
WHERE parent_record_id IS NOT 0
AND `deleted_at` IS NULL
ERROR - 2015-11-26 20:40:32 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:40:32 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:16 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:18 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:26 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:41:26 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:42:13 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:42:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:42:16 --> 404 Page Not Found: Orders/table_orders
ERROR - 2015-11-26 20:43:09 --> Severity: Notice --> Undefined variable: tables C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:43:09 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\tables_view.php 4
ERROR - 2015-11-26 20:53:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Tables.php 29
ERROR - 2015-11-26 21:00:08 --> Query error: Unknown column 'table_record_id' in 'where clause' - Invalid query: SELECT *
FROM `orders`
WHERE `table_record_id` = '5'
AND `deleted_at` IS NULL
ERROR - 2015-11-26 21:07:23 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:07:23 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:07:25 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:07:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:07:26 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:07:58 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:07:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:00 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:01 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:02 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:08:10 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:10 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:10 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:08:14 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:20 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:20 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:22 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:08:24 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:24 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:24 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:31 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:32 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:08:34 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:08:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:26 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:34 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:09:36 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:09:37 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:09:39 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:39 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:41 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:42 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:43 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:44 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:45 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:46 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:47 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:09:49 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:10:11 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:10:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:10:39 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:11:37 --> Severity: Parsing Error --> syntax error, unexpected ''?>'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:11:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:12:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:14:42 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:15:55 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:00 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:01 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:02 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:03 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:06 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:09 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:36 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:38 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:40 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:17:55 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:18 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-26 21:18:18 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:18 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-26 21:18:18 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:28 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-26 21:18:28 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:35 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-26 21:18:35 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:49 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:49 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:49 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:50 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:50 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:50 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:51 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:51 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:51 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:53 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:53 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:53 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:54 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:54 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:54 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:57 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:57 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:18:58 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:18:58 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:19:27 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:19:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:19:27 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:19:35 --> Severity: Notice --> Undefined variable: table C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:19:35 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\core\MY_Controller.php 59
ERROR - 2015-11-26 21:19:35 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:20:07 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:20:16 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:20:18 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:20:30 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 61
ERROR - 2015-11-26 21:20:41 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 61
ERROR - 2015-11-26 21:20:49 --> Severity: Notice --> Undefined variable: new_order_link C:\projects\catering.loc\application\core\MY_Controller.php 63
ERROR - 2015-11-26 21:21:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:21:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:21:37 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:22:50 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:22:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:28:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-26 21:29:08 --> 404 Page Not Found: Assets/plugins
