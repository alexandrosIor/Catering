<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-11 09:56:59 --> 404 Page Not Found: Faviconico/index
