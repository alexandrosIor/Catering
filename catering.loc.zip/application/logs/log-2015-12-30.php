<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-30 20:37:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-30 20:37:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:37:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:37:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:37:25 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-30 20:39:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:39:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:40:04 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:40:09 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:41:11 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:45:11 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:49:26 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:49:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:49:37 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:51:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:51:19 --> Severity: Error --> Cannot access protected property WebSocket\Client::$is_connected C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 20:52:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:53:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:53:53 --> Severity: Error --> Call to undefined method WebSocket\Client::is_connected() C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 20:54:42 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:56:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:56:51 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 20:57:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:58:02 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 38
ERROR - 2015-12-30 20:58:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:58:23 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 20:58:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-30 20:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-30 20:58:56 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 20:59:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 20:59:15 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 21:00:08 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Waiter_new_order.php 186
ERROR - 2015-12-30 21:00:09 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Waiter_new_order.php 186
ERROR - 2015-12-30 21:00:09 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Waiter_new_order.php 186
ERROR - 2015-12-30 21:00:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:00:31 --> Severity: Parsing Error --> syntax error, unexpected '@', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\libraries\Websocket_messages_lib.php 36
ERROR - 2015-12-30 21:04:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:05:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:05:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:05:44 --> Severity: Error --> Cannot break/continue 1 level C:\projects\catering.loc\application\controllers\Waiter_new_order.php 191
ERROR - 2015-12-30 21:06:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:07:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:07:15 --> Severity: Compile Error --> Cannot use try without catch or finally C:\projects\catering.loc\application\controllers\Waiter_new_order.php 189
ERROR - 2015-12-30 21:07:16 --> Severity: Compile Error --> Cannot use try without catch or finally C:\projects\catering.loc\application\controllers\Waiter_new_order.php 189
ERROR - 2015-12-30 21:07:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:09:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:09:45 --> Severity: error --> Exception: Could not open socket to "127.0.0.1:8087": No connection could be made because the target machine actively refused it.
 (10061). C:\projects\catering.loc\application\vendor\textalk\websocket\lib\Client.php 60
ERROR - 2015-12-30 21:13:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:14:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:16:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:16:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-30 21:16:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:16:14 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-30 21:16:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:16:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:19:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:20:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:22:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:22:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:29:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:29:08 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\projects\catering.loc\application\controllers\Waiter_new_order.php 55
ERROR - 2015-12-30 21:29:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-30 21:29:59 --> 404 Page Not Found: Assets/plugins
