<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-07 10:00:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-07 10:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-07 10:00:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-07 10:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-07 10:00:30 --> 404 Page Not Found: Faviconico/index
