<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Notice --> Object of class Shift_model could not be converted to int C:\projects\catering.loc\application\controllers\Shifts.php 45
ERROR - 2016-02-26 00:30:53 --> Severity: Warning --> usort(): Array was modified by the user comparison function C:\projects\catering.loc\application\controllers\Shifts.php 46
ERROR - 2016-02-26 00:34:31 --> Severity: Warning --> usort() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 44
ERROR - 2016-02-26 00:34:45 --> Severity: Warning --> usort() expects parameter 2 to be a valid callback, class 'Shifts' does not have a method 'insert_at' C:\projects\catering.loc\application\controllers\Shifts.php 44
ERROR - 2016-02-26 00:35:03 --> Severity: Warning --> usort() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 44
