<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-23 06:26:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-23 07:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-23 07:57:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 07:57:04 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\catalogue\catalogue_view.php 9
ERROR - 2015-11-23 07:57:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\catalogue\catalogue_view.php 9
ERROR - 2015-11-23 07:57:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 07:58:36 --> Severity: Notice --> Undefined property: Catalogue::$children C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 07:58:36 --> Severity: Notice --> Undefined property: Catalogue::$children C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 07:58:36 --> Severity: Notice --> Undefined property: Catalogue::$children C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 07:58:36 --> Severity: Notice --> Undefined property: Catalogue::$children C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 07:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 07:59:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:00:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:01:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:01:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:01:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:01:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:04:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:05:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:05:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:06:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:06:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:06:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:06:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:07:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:07:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:07:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:08:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:09:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:09:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:09:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:10:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:12:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:13:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:13:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:14:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:16:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:16:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:18:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:20:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:22:03 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:22:16 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:22:26 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:22:37 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:24:05 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:24:35 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:25:01 --> Severity: Notice --> Undefined property: Catalogue::$status C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-11-23 08:26:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:28:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:29:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:30:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:30:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:30:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:33:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:33:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:33:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:34:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:34:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:36:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:36:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:39:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:42:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:43:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:44:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:46:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:46:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:47:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:47:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:48:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:48:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:48:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:49:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:56:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:57:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:58:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:58:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 08:58:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 09:01:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 09:04:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 09:04:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 21:22:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-23 21:22:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-23 21:24:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-23 21:24:30 --> 404 Page Not Found: Faviconico/index
