<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-24 14:05:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-24 14:06:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:12:51 --> 404 Page Not Found: Orders/print_order_modal_form
ERROR - 2016-01-24 14:19:05 --> Severity: Error --> Call to a member function order_products() on array C:\projects\catering.loc\application\controllers\Orders.php 238
ERROR - 2016-01-24 14:19:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:19:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:19:57 --> Severity: Error --> Call to a member function order_products() on array C:\projects\catering.loc\application\controllers\Orders.php 238
ERROR - 2016-01-24 14:21:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:21:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:21:13 --> Severity: Notice --> Undefined variable: modal_title C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 3
ERROR - 2016-01-24 14:21:13 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 16
ERROR - 2016-01-24 14:21:13 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 16
ERROR - 2016-01-24 14:21:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:21:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:21:31 --> Severity: Error --> Call to a member function order_products() on array C:\projects\catering.loc\application\controllers\Orders.php 239
ERROR - 2016-01-24 14:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:22:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:22:04 --> Severity: 4096 --> Object of class Order_model could not be converted to string C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:04 --> Severity: Notice --> Object of class Order_model to string conversion C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:04 --> Severity: Notice --> Undefined variable: product_categories C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 16
ERROR - 2016-01-24 14:22:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 16
ERROR - 2016-01-24 14:22:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:22:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:22:34 --> Severity: 4096 --> Object of class Order_model could not be converted to string C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:34 --> Severity: Notice --> Object of class Order_model to string conversion C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\controllers\Orders.php 241
ERROR - 2016-01-24 14:22:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:22:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:27:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:28:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:28:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:30:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:34:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:34:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:34:46 --> Severity: Notice --> Undefined property: Orders::$cost C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 14:34:46 --> Severity: Notice --> Undefined property: Orders::$cost C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 14:34:46 --> Severity: Notice --> Undefined property: Orders::$cost C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 14:34:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:34:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:35:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:37:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:37:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:37:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:37:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:38:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:38:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:38:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:40:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:40:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:40:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:47:43 --> Severity: Warning --> substr() expects parameter 3 to be long, string given C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 10
ERROR - 2016-01-24 14:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 14:50:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Undefined variable: order C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Undefined variable: order C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Undefined variable: order C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:05:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Shifts.php 51
ERROR - 2016-01-24 15:26:22 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:26:56 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:27:01 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:27:44 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:27:48 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:27:51 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:28:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:28:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:28:07 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:28:43 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:28:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:40 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:29:45 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:29:48 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:29:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:57 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:29:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:29:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:03 --> 404 Page Not Found: Assets/js
ERROR - 2016-01-24 15:30:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:32 --> 404 Page Not Found: Shifts/datatable_shifts_details_data
ERROR - 2016-01-24 15:30:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:50 --> 404 Page Not Found: Shifts/datatable_shift_details_data
ERROR - 2016-01-24 15:30:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:30:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:17 --> Severity: Notice --> Undefined variable: data C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:31:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:17 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:31:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:27 --> Severity: Notice --> Undefined variable: data C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:31:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:31:27 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:32:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:32:05 --> Severity: Notice --> Undefined variable: data C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:32:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:32:05 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:32:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:32:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:32:38 --> Severity: Notice --> Undefined variable: data C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:32:38 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given C:\projects\catering.loc\application\controllers\Shifts.php 96
ERROR - 2016-01-24 15:33:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:33:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:33:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:33:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:35:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:37:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:37:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:16 --> 404 Page Not Found: Shifts/datatable_shift_details_dataundefined
ERROR - 2016-01-24 15:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:38:59 --> Severity: Notice --> Undefined variable: shift C:\projects\catering.loc\application\controllers\Shifts.php 95
ERROR - 2016-01-24 15:38:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Shifts.php 95
ERROR - 2016-01-24 15:39:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:39:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:39:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:39:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:40:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:40:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:41:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:41:02 --> 404 Page Not Found: Orders/order_details
ERROR - 2016-01-24 15:41:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:41:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:42:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:42:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:43:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:43:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:43:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:43:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:44:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:44:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:45:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:45:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:46:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:46:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:46:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:46:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:51:08 --> Query error: Unknown column 'shift_record_id' in 'where clause' - Invalid query: SELECT *
FROM `shifts`
WHERE `shift_record_id` = '1'
AND `deleted_at` IS NULL
ERROR - 2016-01-24 15:51:24 --> Query error: Unknown column 'shift_record_id' in 'where clause' - Invalid query: SELECT *
FROM `shifts`
WHERE `shift_record_id` = '1'
AND `deleted_at` IS NULL
ERROR - 2016-01-24 15:52:07 --> Query error: Unknown column 'shift_record_id' in 'where clause' - Invalid query: SELECT *
FROM `shifts`
WHERE `shift_record_id` = '1'
AND `deleted_at` IS NULL
ERROR - 2016-01-24 15:52:27 --> Severity: Error --> Call to a member function shift_orders() on array C:\projects\catering.loc\application\controllers\Shifts.php 75
ERROR - 2016-01-24 15:52:46 --> Severity: Notice --> Undefined property: Shifts::$time_worked C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 15:52:46 --> Severity: Notice --> Undefined property: Shifts::$total_orders C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 15:52:46 --> Severity: Notice --> Undefined property: Shifts::$unpaid_orders C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 15:52:46 --> Severity: Notice --> Undefined property: Shifts::$completed_orders C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-24 15:52:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:53:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:53:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:54:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:54:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:54:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:55:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:56:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:56:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:57:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:57:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:57:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:57:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:58:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 15:59:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:00:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:00:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:02:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:02:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:03:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:15:44 --> Severity: Error --> Call to undefined function time_zone_greece() C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 10
ERROR - 2016-01-24 16:15:56 --> Severity: Error --> Call to undefined function time_zone_greece() C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 10
ERROR - 2016-01-24 16:16:36 --> Severity: Error --> Call to undefined function time_zone_greece() C:\projects\catering.loc\application\controllers\Orders.php 246
ERROR - 2016-01-24 16:16:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:16:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:16:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:16:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:16:55 --> Severity: Error --> Call to undefined function time_zone_greece() C:\projects\catering.loc\application\controllers\Orders.php 246
ERROR - 2016-01-24 16:17:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:17:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:17:40 --> Severity: Warning --> substr() expects at least 2 parameters, 1 given C:\projects\catering.loc\application\views\store\orders\print_order_modal_form.php 10
ERROR - 2016-01-24 16:18:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:18:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:19:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:19:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-24 16:19:19 --> 404 Page Not Found: Assets/plugins
