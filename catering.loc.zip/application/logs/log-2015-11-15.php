<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-15 00:33:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-15 00:33:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-15 00:39:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 09:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-15 09:17:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 09:17:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 17:10:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-15 17:10:20 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:10:31 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:10:37 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:10:39 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-15 17:10:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 17:10:56 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:10:59 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:00 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:00 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:02 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:17 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 17:11:24 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:25 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:11:25 --> Severity: Error --> Call to undefined method MY_Model::update_properties() C:\projects\catering.loc\application\core\MY_Model.php 20
ERROR - 2015-11-15 17:12:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 17:44:50 --> 404 Page Not Found: Waiter/orders
ERROR - 2015-11-15 18:00:28 --> Severity: Notice --> Undefined index: test C:\projects\catering.loc\application\controllers\Orders.php 32
ERROR - 2015-11-15 18:00:55 --> Severity: Notice --> Undefined index: test C:\projects\catering.loc\application\controllers\Orders.php 32
ERROR - 2015-11-15 18:01:50 --> Severity: Notice --> Undefined index: test C:\projects\catering.loc\application\controllers\Orders.php 32
ERROR - 2015-11-15 18:02:07 --> Severity: Notice --> Undefined index: test C:\projects\catering.loc\application\controllers\Orders.php 32
ERROR - 2015-11-15 18:18:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 18:19:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-15 23:07:19 --> 404 Page Not Found: Ratchet/index
