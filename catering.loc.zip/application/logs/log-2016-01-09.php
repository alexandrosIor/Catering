<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-09 14:50:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-09 14:52:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:21:42 --> Severity: Parsing Error --> syntax error, unexpected '}' C:\projects\catering.loc\application\controllers\Orders.php 109
ERROR - 2016-01-09 15:22:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:22:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:22:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:22:19 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-09 15:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-09 15:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-09 15:22:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:23:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:25:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:26:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:29:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:30:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:31:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:31:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:32:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:33:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:37:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:37:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:38:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:39:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:41:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:41:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:47:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:47:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:51:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:53:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-09 15:54:28 --> 404 Page Not Found: Assets/plugins
