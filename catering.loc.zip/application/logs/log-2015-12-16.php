<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-16 19:48:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-16 19:48:40 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-16 19:48:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 19:48:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 19:52:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 19:55:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 19:57:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:00:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:00:49 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 48
ERROR - 2015-12-16 20:01:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:01:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:01:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:02:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:02:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:02:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:03:48 --> Severity: Notice --> Undefined property: Orders::$reocrd_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-16 20:05:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:05:35 --> Severity: Notice --> Undefined property: Orders::$reocord_id C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-16 20:05:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:07:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:08:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:09:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:09:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:10:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:11:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:12:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:14:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:18:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:19:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:19:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:20:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:22:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:22:14 --> Severity: Parsing Error --> syntax error, unexpected ',', expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 44
ERROR - 2015-12-16 20:22:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:23:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-16 20:23:47 --> 404 Page Not Found: Assets/plugins
