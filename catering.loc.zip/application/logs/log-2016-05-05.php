<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-05-05 13:43:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-05-05 13:48:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-05-05 13:48:41 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-05-05 13:48:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-05-05 13:49:38 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 140
ERROR - 2016-05-05 13:52:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 140
ERROR - 2016-05-05 13:56:53 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-05-05 13:59:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-05-05 14:02:26 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 33
ERROR - 2016-05-05 14:02:32 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 33
