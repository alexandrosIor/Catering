<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-17 18:54:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-17 18:54:14 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-17 18:54:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 18:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 18:59:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:00:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:29:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:56 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:57 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 38
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 39
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 41
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 47
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:29:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\catalogue.php 59
ERROR - 2015-12-17 19:30:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:30:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:36:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:37:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:38:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:39:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:39:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:40:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:40:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:41:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:41:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:42:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:42:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:44:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:44:05 --> Severity: Notice --> Undefined property: Orders::$short_description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:44:05 --> Severity: Notice --> Undefined property: Orders::$description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:44:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:44:18 --> Severity: Notice --> Undefined property: Orders::$short_description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:44:18 --> Severity: Notice --> Undefined property: Orders::$description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:45:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:45:23 --> Severity: Notice --> Undefined property: Orders::$short_description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:45:23 --> Severity: Notice --> Undefined property: Orders::$description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:46:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:46:30 --> Severity: Notice --> Undefined property: Orders::$short_description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:46:30 --> Severity: Notice --> Undefined property: Orders::$description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:46:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:46:55 --> Severity: Notice --> Undefined property: Orders::$short_description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:46:55 --> Severity: Notice --> Undefined property: Orders::$description C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 19:48:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:48:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:49:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:49:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:50:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:50:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:51:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:51:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:52:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:52:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:52:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:56:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:57:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 19:57:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:00:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:00:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:01:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:01:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:03:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:03:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:04:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:05:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:07:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:08:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:09:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:10:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:11:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:15:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:15:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:26:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:26:41 --> Severity: Notice --> Undefined property: Orders::$delete C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 20:27:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:28:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:28:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:28:52 --> Severity: Notice --> Undefined property: Orders::$delete C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 20:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:35:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:37:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:37:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:40:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:40:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:47:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:48:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:49:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:49:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:49:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 20:50:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:00:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:04:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:05:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:06:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:08:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:10:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:10:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:12:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:12:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:16:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:17:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:18:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:21:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:22:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:25:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:25:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:25:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:26:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:26:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:27:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:28:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:28:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:29:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:34:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:34:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:37:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:38:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:41:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:42:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:42:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:44:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:45:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:45:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:46:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 21:49:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:07:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:07:09 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:07:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:07:27 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:07:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:07:39 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:08:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:08:01 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:08:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:08:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:09:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:09:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:09:31 --> Severity: Notice --> Undefined property: Orders::$info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 22:09:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 83
ERROR - 2015-12-17 22:09:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:10:10 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:10:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:10:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:10:43 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:10:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:11:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:11:26 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:11:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:11:38 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:11:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:11:54 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:12:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:12:22 --> Severity: Notice --> Undefined property: Orders::$info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2015-12-17 22:12:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 83
ERROR - 2015-12-17 22:13:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:13:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:14:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:14:38 --> Query error: Unknown column 'order_record_id' in 'field list' - Invalid query: INSERT INTO `orders` (`table_record_id`, `user_record_id`, `shift_record_id`, `record_id`, `insert_at`, `update_at`, `deleted_at`, `order_record_id`) VALUES ('2', NULL, NULL, NULL, '2015-12-17 21:14:38', '2015-12-17 21:14:38', NULL, '1')
ERROR - 2015-12-17 22:19:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:19:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:20:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:22:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:22:39 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:22:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:23:00 --> Severity: Parsing Error --> syntax error, unexpected ')', expecting ']' C:\projects\catering.loc\application\controllers\Orders.php 127
ERROR - 2015-12-17 22:23:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:23:28 --> Severity: Parsing Error --> syntax error, unexpected ']' C:\projects\catering.loc\application\controllers\Orders.php 128
ERROR - 2015-12-17 22:23:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:25:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:27:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:28:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:31:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:34:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:35:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:36:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:37:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:38:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:39:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:40:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-17 22:51:13 --> 404 Page Not Found: Img/icon.png
