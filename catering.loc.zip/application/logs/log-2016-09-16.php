<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-16 14:16:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-09-16 14:19:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-09-16 14:19:51 --> 404 Page Not Found: Assets/plugins
