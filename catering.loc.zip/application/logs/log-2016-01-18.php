<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-18 17:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 18:08:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:08:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:10:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:10:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:11:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:11:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:12:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:12:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:12:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:31:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:31:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:32:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:32:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:32:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:32:38 --> Severity: Error --> Call to a member function store_table_info() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 136
ERROR - 2016-01-18 18:32:46 --> Severity: Error --> Call to a member function store_table_info() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 136
ERROR - 2016-01-18 18:33:04 --> Severity: Error --> Call to a member function store_table_info() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 136
ERROR - 2016-01-18 18:33:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:33:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:33:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:33:36 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-18 18:33:47 --> Severity: Error --> Call to a member function store_table_info() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 136
ERROR - 2016-01-18 18:34:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:34:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 18:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 18:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 18:36:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:36:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:36:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:37:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:38:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:40:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:41:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:44:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:45:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:47:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:48:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:53:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:53:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:54:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:54:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:55:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:56:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:57:05 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 18:57:05 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 18:57:05 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 18:57:05 --> Query error: Unknown column 'store_table_info' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-18 17:56:51', `end_date` = '2016-01-18 17:57:05', `payment_status` = 'pending', `record_id` = '29', `insert_at` = '2016-01-18 17:56:46', `update_at` = '2016-01-18 17:57:05', `deleted_at` = NULL, `store_table_info` = NULL, `user_info` = NULL, `order_products` = NULL
WHERE `record_id` = '29'
ERROR - 2016-01-18 18:57:10 --> Severity: Error --> Call to a member function product_info() on null C:\projects\catering.loc\application\controllers\Waiter_new_order.php 134
ERROR - 2016-01-18 18:58:26 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:58:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:58:29 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:58:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:58:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 18:58:44 --> Severity: Notice --> Undefined variable: product C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:58:44 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\store\orders\order_modal_form.php 77
ERROR - 2016-01-18 18:59:17 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 18:59:17 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-18 17:59:00', `end_date` = '2016-01-18 17:59:17', `payment_status` = 'paid', `record_id` = '30', `insert_at` = '2016-01-18 17:58:54', `update_at` = '2016-01-18 17:59:17', `deleted_at` = NULL, `order_products` = NULL
WHERE `record_id` = '30'
ERROR - 2016-01-18 19:00:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:00:40 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 19:00:40 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-18 18:00:34', `end_date` = '2016-01-18 18:00:40', `payment_status` = 'pending', `record_id` = '31', `insert_at` = '2016-01-18 18:00:30', `update_at` = '2016-01-18 18:00:40', `deleted_at` = NULL, `order_products` = NULL
WHERE `record_id` = '31'
ERROR - 2016-01-18 19:01:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:02:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:03:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:07:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:07:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:08:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:09:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:09:49 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:09:52 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:10:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:17 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:39 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 19:10:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:12:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:12:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:17:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:18:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:19:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:20:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:24:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:25:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:27:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:28:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:28:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:29:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:29:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:32:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:32:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:38:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:45:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:46:01 --> Severity: Warning --> trim() expects parameter 1 to be string, object given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 19:46:01 --> Query error: Unknown column 'product_info' in 'field list' - Invalid query: UPDATE `order_products` SET `order_record_id` = '55', `product_record_id` = '9', `quantity` = '2', `comments` = NULL, `record_id` = '95', `insert_at` = '2016-01-18 18:32:19', `update_at` = '2016-01-18 18:46:01', `deleted_at` = NULL, `product_info` = NULL
WHERE `record_id` = '95'
ERROR - 2016-01-18 19:46:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:47:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:48:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:49:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:50:52 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 221
ERROR - 2016-01-18 19:53:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:53:30 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 221
ERROR - 2016-01-18 19:54:05 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 221
ERROR - 2016-01-18 19:54:28 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 221
ERROR - 2016-01-18 19:54:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 226
ERROR - 2016-01-18 19:55:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:55:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 19:58:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:01:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:01:34 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:02:26 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:03:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:03:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:03:54 --> Severity: Notice --> Undefined variable: total_price C:\projects\catering.loc\application\controllers\Waiter.php 94
ERROR - 2016-01-18 20:04:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:04:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:05:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:05:58 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 20:05:58 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-12 23:15:40', `end_date` = '2016-01-13 18:54:28', `payment_status` = 'deleted', `record_id` = '4', `insert_at` = '2016-01-12 23:15:35', `update_at` = '2016-01-18 19:05:58', `deleted_at` = NULL, `order_products` = NULL, `total_price` = 0
WHERE `record_id` = '4'
ERROR - 2016-01-18 20:06:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:06:30 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 20:06:30 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-12 23:15:40', `end_date` = '2016-01-13 18:54:28', `payment_status` = 'deleted', `record_id` = '4', `insert_at` = '2016-01-12 23:15:35', `update_at` = '2016-01-18 19:06:30', `deleted_at` = NULL, `order_products` = NULL
WHERE `record_id` = '4'
ERROR - 2016-01-18 20:06:41 --> Severity: Parsing Error --> syntax error, unexpected '$order' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Waiter.php 110
ERROR - 2016-01-18 20:06:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:06:47 --> Severity: Warning --> trim() expects parameter 1 to be string, array given C:\projects\catering.loc\application\core\MY_Model.php 38
ERROR - 2016-01-18 20:06:47 --> Query error: Unknown column 'order_products' in 'field list' - Invalid query: UPDATE `orders` SET `store_table_record_id` = '1', `user_record_id` = '2', `shift_record_id` = NULL, `start_date` = '2016-01-12 23:15:40', `end_date` = '2016-01-13 18:54:28', `payment_status` = 'deleted', `record_id` = '4', `insert_at` = '2016-01-12 23:15:35', `update_at` = '2016-01-18 19:06:47', `deleted_at` = NULL, `order_products` = NULL
WHERE `record_id` = '4'
ERROR - 2016-01-18 20:07:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:07:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:07:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:07:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:08:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:08:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:09:33 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:09:33 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:09:33 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:09:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:09:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:10:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:10:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:10:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:11:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:11:45 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:11:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:13:11 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:13:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:13:11 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:15:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:15:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:16:03 --> Severity: Notice --> Undefined property: Waiter::$store_table_info C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:16:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\views\waiter\order_chip_view.php 11
ERROR - 2016-01-18 20:16:03 --> Severity: Notice --> Undefined property: Waiter::$elapsed_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-18 20:16:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:17:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:18:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:20:03 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:20:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:20:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:22:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:22:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:22:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:23:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:23:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:24:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:24:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:24:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:25:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-01-18 20:25:02 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 226
ERROR - 2016-01-18 20:25:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-01-18 20:25:02 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 226
ERROR - 2016-01-18 20:25:16 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 224
ERROR - 2016-01-18 20:25:16 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 226
ERROR - 2016-01-18 20:26:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:26:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:28:27 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-18 20:28:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:28:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:29:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 20:29:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 20:29:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:29:41 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:30:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:30:09 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:30:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:30:24 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:31:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:31:47 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:32:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:33:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:35:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:35:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:36:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:37:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:37:44 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:38:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:39:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:40:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:40:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:41:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:43:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:44:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:44:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:45:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:47:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:48:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:49:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:52:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:52:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:56:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 20:57:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:57:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:57:15 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:57:18 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:57:18 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:57:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 20:57:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:57:57 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:57:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:57:59 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:58:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:58:01 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:58:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:58:01 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:58:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:58:02 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:58:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 20:58:04 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 20:59:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:01:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:04:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 138
ERROR - 2016-01-18 21:08:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:08:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:09:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:09:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:10:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:10:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:14:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:14:13 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 21:14:19 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 21:22:39 --> Severity: Compile Error --> Cannot redeclare Waiter::ajax_order_served() C:\projects\catering.loc\application\controllers\Waiter.php 185
ERROR - 2016-01-18 21:22:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 21:23:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:26:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:27:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:29:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:30:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:31:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:32:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:33:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:35:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:37:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:37:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:38:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:39:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:39:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:40:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:41:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:41:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:42:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:45:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:54:39 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:56:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:57:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:57:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 21:57:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:06:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:06:08 --> Severity: Notice --> Undefined property: Waiter::$order_model C:\projects\catering.loc\application\controllers\Waiter.php 215
ERROR - 2016-01-18 22:06:08 --> Severity: Error --> Call to a member function get_record() on null C:\projects\catering.loc\application\controllers\Waiter.php 215
ERROR - 2016-01-18 22:06:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:06:37 --> Severity: Error --> Cannot use object of type Order_product_model as array C:\projects\catering.loc\application\controllers\Waiter.php 216
ERROR - 2016-01-18 22:07:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:07:43 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:07:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:08:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:09:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:09:02 --> Severity: Error --> Call to undefined method Websocket_messages_lib::waiter_order_update() C:\projects\catering.loc\application\controllers\Waiter.php 224
ERROR - 2016-01-18 22:09:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:13:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:11 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 221
ERROR - 2016-01-18 22:17:11 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 225
ERROR - 2016-01-18 22:17:13 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 221
ERROR - 2016-01-18 22:17:13 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 225
ERROR - 2016-01-18 22:17:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:18 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 221
ERROR - 2016-01-18 22:17:18 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 225
ERROR - 2016-01-18 22:17:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:24 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 221
ERROR - 2016-01-18 22:17:24 --> Severity: Notice --> Undefined index: status C:\projects\catering.loc\application\controllers\Waiter.php 225
ERROR - 2016-01-18 22:17:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:17:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:20:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:21:07 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 22:21:07 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:21:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 22:21:08 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:21:10 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Waiter_new_order.php 223
ERROR - 2016-01-18 22:21:10 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:30:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:31:07 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:31:23 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 22:32:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:32:36 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:32:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:39:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:43:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:43:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:45:51 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:46:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:46:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:48:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:49:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:49:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:51:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:51:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:51:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:52:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:54:58 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:55:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:55:17 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:55:32 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 22:56:03 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:03 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:07 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 22:56:10 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:10 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:16 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:16 --> 404 Page Not Found: Assets/socket.js
ERROR - 2016-01-18 22:56:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:57:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 22:59:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:02:03 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:02:04 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:02:11 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 23:02:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:02:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:03:39 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:03:39 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:03:48 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:03:49 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:05:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:05:16 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:05:16 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:05:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:13:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-18 23:13:20 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-18 23:13:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:13:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:13:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:13:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:17:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:17:50 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:17:51 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:17:57 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 23:18:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:18:21 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:18:22 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:18:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:19:02 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:19:03 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:19:11 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
ERROR - 2016-01-18 23:20:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:20:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:05 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:16 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:21 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:48 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:21:51 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:52 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:53 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:53 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:21:54 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:22:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:22:25 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:23:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:23:07 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:23:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:23:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:23:30 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:23:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:23:49 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:23:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:23:58 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:24:19 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:24:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:24:37 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:38 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:24:39 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:25:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:25:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:25:41 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:27:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:27:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:27:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:27:58 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:27:59 --> Severity: Notice --> Undefined index: comments C:\projects\catering.loc\application\controllers\Waiter_new_order.php 225
ERROR - 2016-01-18 23:28:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-18 23:28:17 --> Severity: Notice --> Undefined index: quantity C:\projects\catering.loc\application\controllers\Waiter_new_order.php 220
