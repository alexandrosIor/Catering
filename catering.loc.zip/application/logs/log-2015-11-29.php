<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-29 12:36:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-29 12:36:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-29 12:36:42 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:47:13 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:47:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:47:24 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:50:11 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:50:14 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:50:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-29 12:50:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-29 12:51:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:52:06 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:52:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:52:26 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:57:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:57:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:58:44 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:58:57 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:58:59 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:00 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:29 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:30 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:31 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 12:59:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:00:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:00:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:00:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:00:09 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:00:58 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:01:02 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:01:06 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:01:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:01:21 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:01:43 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:09:31 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) C:\projects\catering.loc\application\controllers\Orders.php 41
ERROR - 2015-11-29 13:09:49 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:09:50 --> 404 Page Not Found: Assets/js
ERROR - 2015-11-29 13:10:05 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:10:06 --> Severity: Notice --> Undefined variable: categories C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:10:06 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:11 --> Severity: Notice --> Undefined variable: categories C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:12 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:11:14 --> Severity: Notice --> Undefined variable: categories C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:28 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:11:28 --> Severity: Notice --> Undefined variable: categories C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:11:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\product_categories_view.php 4
ERROR - 2015-11-29 13:12:03 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:12:03 --> Severity: Notice --> Undefined variable: products C:\projects\catering.loc\application\views\waiter\orders\products_view.php 4
ERROR - 2015-11-29 13:12:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\products_view.php 4
ERROR - 2015-11-29 13:12:07 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:12:07 --> Severity: Notice --> Undefined variable: products C:\projects\catering.loc\application\views\waiter\orders\products_view.php 4
ERROR - 2015-11-29 13:12:07 --> Severity: Warning --> Invalid argument supplied for foreach() C:\projects\catering.loc\application\views\waiter\orders\products_view.php 4
ERROR - 2015-11-29 13:12:23 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:12:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:13:08 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:13:12 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:13:15 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:13:18 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:19 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:22 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:25 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:27 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:30 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:32 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:14:35 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:18:53 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:19:01 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:19:04 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 13:19:36 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 11:20:39 --> Severity: Notice --> Trying to get property of non-object C:\projects\catering.loc\application\controllers\Orders.php 26
ERROR - 2015-11-29 21:07:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-29 21:07:50 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-29 21:08:07 --> 404 Page Not Found: Codec-blue/index
ERROR - 2015-11-29 21:08:12 --> 404 Page Not Found: Codec-blue/index.php
ERROR - 2015-11-29 21:12:39 --> 404 Page Not Found: Mobileloc/index
ERROR - 2015-11-29 21:12:51 --> 404 Page Not Found: Mobileloc/index
ERROR - 2015-11-29 21:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-29 21:14:43 --> 404 Page Not Found: Assets/plugins
