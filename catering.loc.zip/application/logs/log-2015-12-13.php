<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-13 01:22:00 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-13 01:23:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 01:23:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 01:28:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-13 01:29:01 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-13 01:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-13 01:32:48 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-12-13 01:32:50 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-12-13 01:33:27 --> 404 Page Not Found: Apple-touch-icon-precomposedpng/index
ERROR - 2015-12-13 01:33:27 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-13 01:33:27 --> 404 Page Not Found: Apple-touch-iconpng/index
ERROR - 2015-12-13 03:01:19 --> 404 Page Not Found: Img/icon.png
ERROR - 2015-12-13 03:01:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-13 21:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-13 21:45:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-12-13 21:45:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:46:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:46:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-12-13 21:47:45 --> 404 Page Not Found: Assets/plugins
