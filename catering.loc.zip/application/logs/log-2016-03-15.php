<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-03-15 10:40:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-15 10:40:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-03-15 10:42:41 --> 404 Page Not Found: Faviconico/index
