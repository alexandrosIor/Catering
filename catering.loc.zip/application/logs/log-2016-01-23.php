<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-23 13:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-23 13:49:07 --> Severity: Error --> Call to undefined method Store::get_records() C:\projects\catering.loc\application\controllers\Store.php 25
ERROR - 2016-01-23 13:49:25 --> Severity: Error --> Call to undefined function get_seconds_diff_from_dates() C:\projects\catering.loc\application\controllers\Store.php 36
ERROR - 2016-01-23 13:50:06 --> Severity: Notice --> Undefined property: Store::$start_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-23 13:50:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:50:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:50:49 --> Severity: Notice --> Undefined property: Store::$start_time C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-23 13:50:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:50:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:51:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:51:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:54:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-23 13:55:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:55:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:56:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:56:18 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:57:41 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:58:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:58:10 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:58:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 13:58:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:00:06 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\projects\catering.loc\application\views\store\dashboard.php 28
ERROR - 2016-01-23 14:05:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:08:26 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:28:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:32:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:32:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:33:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:33:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:34:46 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 32
ERROR - 2016-01-23 14:34:52 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 32
ERROR - 2016-01-23 14:35:01 --> Severity: Error --> Call to a member function shift_orders() on null C:\projects\catering.loc\application\controllers\Waiter.php 32
ERROR - 2016-01-23 14:35:16 --> 404 Page Not Found: Img/icon.png
ERROR - 2016-01-23 14:35:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:35:21 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:35:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:35:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-23 14:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2016-01-23 14:47:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:47:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:47:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:47:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:47:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:48:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:48:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:48:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:48:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:54:37 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:54:56 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:54:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:55:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:56:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:56:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:07 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:57:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:59:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:59:49 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:59:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 14:59:53 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:23 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:00:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:04:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:07:54 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:08:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:08:47 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:10:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:11:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:11:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:36:49 --> Severity: Parsing Error --> syntax error, unexpected '[', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Store.php 75
ERROR - 2016-01-23 15:37:10 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Store.php 75
ERROR - 2016-01-23 15:37:11 --> Severity: Parsing Error --> syntax error, unexpected '(', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' C:\projects\catering.loc\application\controllers\Store.php 75
ERROR - 2016-01-23 15:37:17 --> Severity: Notice --> Undefined property: Store::$fisrtname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-23 15:37:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:37:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:04 --> Severity: Notice --> Undefined property: Store::$fisrtname C:\projects\catering.loc\system\core\Model.php 77
ERROR - 2016-01-23 15:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:38:59 --> Severity: Error --> Function name must be a string C:\projects\catering.loc\application\controllers\Store.php 75
ERROR - 2016-01-23 15:40:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:40:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:40:56 --> Severity: Error --> Function name must be a string C:\projects\catering.loc\application\controllers\Store.php 76
ERROR - 2016-01-23 15:42:16 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:42:17 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:42:18 --> Severity: Error --> Function name must be a string C:\projects\catering.loc\application\controllers\Store.php 76
ERROR - 2016-01-23 15:42:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:42:46 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:27 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:29 --> Severity: Error --> Function name must be a string C:\projects\catering.loc\application\controllers\Store.php 75
ERROR - 2016-01-23 15:43:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:43:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:46:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:46:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:46:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:47:45 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:48:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:48:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:48:52 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:48:59 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:49:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:49:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:49:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:50:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:50:25 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:50:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:50:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:50:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:51:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:51:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:51:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:52:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:52:38 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:52:42 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:55:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:55:15 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:56:05 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:58:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:58:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:59:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:59:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:59:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 15:59:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:00:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:00:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:00:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:00:40 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:01:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:01:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:02:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:02:00 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:03:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:09 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:20 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:05:32 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:06:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:07:24 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:07:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:07:55 --> 404 Page Not Found: Assets/plugins
ERROR - 2016-01-23 16:22:14 --> 404 Page Not Found: Faviconico/index
