<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-11-24 04:07:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 04:07:43 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 04:35:44 --> Query error: Unknown column 'caption' in 'field list' - Invalid query: INSERT INTO `product_categories` (`caption`, `insert_at`, `seats`) VALUES ('1','2015-11-24 03:35:44','4'), ('2','2015-11-24 03:35:44','6'), ('3','2015-11-24 03:35:44','2'), ('4','2015-11-24 03:35:44','10'), ('5','2015-11-24 03:35:44','4'), ('6','2015-11-24 03:35:44','4'), ('πίσω γωνία','2015-11-24 03:35:44','2')
ERROR - 2015-11-24 04:35:57 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 301
ERROR - 2015-11-24 04:36:00 --> Severity: Parsing Error --> syntax error, unexpected '?>', expecting function (T_FUNCTION) C:\projects\catering.loc\application\migrations\20151101000000_Initial.php 301
ERROR - 2015-11-24 04:39:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:39:08 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:39:13 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:39:22 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:39:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:43:12 --> Severity: Notice --> Array to string conversion C:\projects\catering.loc\system\database\DB_query_builder.php 1496
ERROR - 2015-11-24 04:43:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'Array' at line 1 - Invalid query: INSERT INTO `product_categories` () VALUES ('2015-11-24 03:43:12','Σαλάτες'), ('2015-11-24 03:43:12','Ορεκτικά κρύα'), ('2015-11-24 03:43:12','Ορεκτικά ζεστά'), ('2015-11-24 03:43:12','Θαλασσινά'), ('2015-11-24 03:43:12','Ψάρια'), ('2015-11-24 03:43:12','Κρεατικά'), ('2015-11-24 03:43:12','Μπύρες'), Array
ERROR - 2015-11-24 04:44:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 04:46:34 --> Query error: Unknown column 'price' in 'field list' - Invalid query: INSERT INTO `products` (`category_record_id`, `insert_at`, `name`, `price`) VALUES ('1','2015-11-24 03:46:34','Σαλάτες',3)
ERROR - 2015-11-24 04:47:00 --> Query error: Unknown column 'price' in 'field list' - Invalid query: INSERT INTO `products` (`category_record_id`, `insert_at`, `name`, `price`) VALUES ('1','2015-11-24 03:47:00','Σαλάτες','3')
ERROR - 2015-11-24 04:49:31 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 05:02:12 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 05:09:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 22:57:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:31:22 --> 404 Page Not Found: Onirocreations/index
ERROR - 2015-11-24 23:32:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:33:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:33:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 23:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 18:31:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2015-11-24 18:34:06 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 18:34:19 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 18:54:52 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 14
ERROR - 2015-11-24 18:54:52 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 16
ERROR - 2015-11-24 18:55:13 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 14
ERROR - 2015-11-24 18:55:13 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 16
ERROR - 2015-11-24 18:55:27 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 14
ERROR - 2015-11-24 18:55:27 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 16
ERROR - 2015-11-24 18:56:20 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 14
ERROR - 2015-11-24 18:56:20 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders_view.php 16
ERROR - 2015-11-24 19:32:04 --> 404 Page Not Found: Assets/plugins
ERROR - 2015-11-24 19:53:49 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:53:50 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:53:52 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:53:54 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:55:45 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:56:10 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 19:56:10 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 19:57:12 --> Severity: Parsing Error --> syntax error, unexpected '''' (T_CONSTANT_ENCAPSED_STRING), expecting ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:01 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:29 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:31 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:40 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:50 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:52 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:58:54 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:59:03 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:59:05 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:59:05 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:59:20 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 19:59:50 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:00:13 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:01:07 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:01:17 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:01:19 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:01:19 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 60
ERROR - 2015-11-24 20:01:56 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 56
ERROR - 2015-11-24 20:02:00 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 56
ERROR - 2015-11-24 20:02:01 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\core\MY_Controller.php 56
ERROR - 2015-11-24 20:02:01 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 5
ERROR - 2015-11-24 20:02:01 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:02:01 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 20:02:32 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 5
ERROR - 2015-11-24 20:02:32 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:02:32 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 20:02:41 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 5
ERROR - 2015-11-24 20:02:41 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:02:41 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 20:03:01 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 5
ERROR - 2015-11-24 20:03:01 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:03:01 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 20:03:22 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:03:22 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 16
ERROR - 2015-11-24 20:03:31 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:03:34 --> Severity: Notice --> Undefined variable: order_record_id C:\projects\catering.loc\application\views\waiter\orders\orders_view.php 14
ERROR - 2015-11-24 20:11:40 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 20:18:37 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 20:47:49 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:00 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:02 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:04 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:08 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:09 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:09 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:09 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:09 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 20:58:09 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:00:20 --> Severity: 4096 --> Object of class Table_model could not be converted to string C:\projects\catering.loc\application\views\waiter\orders\popover_table_select.php 7
ERROR - 2015-11-24 21:18:50 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 21:20:50 --> Severity: Notice --> Undefined variable: title C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 21:46:38 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
ERROR - 2015-11-24 21:46:40 --> Severity: Notice --> Undefined variable: table_record_id C:\projects\catering.loc\application\views\waiter_layout_mobile_view.php 30
