<div class="row">
	<div class="col-md-12">
		<div class="panel panel-white">
			<div class="panel-body">
			   <div class="table-responsive">
				<table id="shifts" class="display table" style="width: 100%; cellspacing: 0;">
					<thead>						
						<tr>
							<th>#</th>
							<th>Έναρξη</th>
							<th>Λήξη</th>
							<th>Ονοματεπώνυμο</th>
							<th>Πόστο</th>
							<th>Παραγγελίες</th>
							<th>Παρέδωσε</th>
							<th>Σύνολο πωλήσεων</th>
							<th>Διαφορά</th>
							<th>Λεπτομέρειες</th>
						</tr>
					</thead>
					<tfoot>
						<tr>
							<th>#</th>
							<th>Έναρξη</th>
							<th>Λήξη</th>
							<th>Ονοματεπώνυμο</th>
							<th>Πόστο</th>
							<th>Παραγγελίες</th>
							<th>Παρέδωσε</th>
							<th>Σύνολο πωλήσεων</th>
							<th>Διαφορά</th>
							<th>Λεπτομέρειες</th>
						</tr>
					</tfoot>
					<tbody>
						
					</tbody>
				   </table>  
				</div>
			</div>
		</div>
	</div>
</div><!-- Row -->