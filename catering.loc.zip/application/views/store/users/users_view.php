
<div class="panel panel-white">
	<div class="panel-body">
		<a class="btn btn-success btn-addon m-b-sm" href="/users/user_modal_form" data-toggle="modal" data-target="#myModal"><i class="fa fa-plus"></i> Νέος χρήστης</a>
		<div class="table-responsive">
			<table id="users" class="display table">
				<thead>
					<tr>
						<th>ID</th>
						<th>Ονομα</th>
						<th>Επίθετο</th>
						<th>Email</th>
						<th>Κωδικός</th>
						<th>Ρόλος</th>
						<th>Κατάσταση</th>
						<th>Διαγραφή</th>
					</tr>
				</thead>
				<tfoot>
					<tr>
						<th>ID</th>
						<th>Ονομα</th>
						<th>Επίθετο</th>
						<th>Email</th>
						<th>Κωδικός</th>
						<th>Ρόλος</th>
						<th>Κατάσταση</th>
						<th>Διαγραφή</th>
					</tr>
				</tfoot>
				<tbody></tbody>
			</table>
		</div>
	</div>
</div>